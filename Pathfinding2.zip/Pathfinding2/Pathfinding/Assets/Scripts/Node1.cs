﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//for encyclopedia, currently just moves
public class Node1{


    // Use this for initialization
    public List<Node1> encyclopedia = new List<Node1>();


    public int moves;
    public Node1(int move)
    {
        moves = move;
    }
}
