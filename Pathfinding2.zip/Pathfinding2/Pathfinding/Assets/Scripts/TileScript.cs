﻿using UnityEngine;
using System.Collections;

public class TileScript : MonoBehaviour {
    public int move;
    public bool clickable;
    public bool isPassable;
	private int xMatrix;
	private int yMatrix;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public int getX()
	{
		int temp = xMatrix;
		return temp;
	}
	public int getY()
	{
		int temp = yMatrix;
		return temp;
	}
	public void setX(int xPosInMatrix)
	{
		xMatrix = xPosInMatrix;
	}
	public void setY(int yPosInMatrix)
	{
		yMatrix = yPosInMatrix;
	}
}
