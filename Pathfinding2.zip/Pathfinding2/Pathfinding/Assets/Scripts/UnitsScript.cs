﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class UnitsScript : MonoBehaviour {
    public int moves;
    public int currentMoves;
    public int counter;
    public int MatrixY;
    public int MatrixX;
    public Sprite blue, red, green, darkgreen, brown;
    private GameObject armyManagerController;
    private GameObject bm;
    public Ray ray;
    public RaycastHit2D hitbox;
	public List<List<int>> moveable;

	// Use this for initialization
	void Start () {
        armyManagerController = GameObject.Find("ArmyManagerController");
        counter = 0;
        currentMoves = moves;
        bm = GameObject.Find("BattleMapCreation");
	}
	
	// Update is called once per frame
	void Update () {
        /*if (Input.GetMouseButtonDown(0))
        {
            //            cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            if (armyManagerController.GetComponent<ArmyManagerController>().movementPhase)
            {

                MatrixX = (int)(transform.parent.position.x / 5);
                MatrixY = (int)(transform.parent.position.y / 5);
                Debug.Log(MatrixX + " HAHA" + MatrixY);
                FindNext(MatrixX, MatrixY, counter);
            }
        }*/
    }

	//Turning this into a 2d list that saves the sqaures that we need to turn blue so we can do them all at once somewhere else.
    public void FindNext(int x, int y, int county)
    {
		if (x > 19 || x < 0 || y > 19 || y < 0) {
			Debug.Log ("OOB");
			return;
		}
		/*if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().isPassable == false) {
			Debug.Log ("ImpTer");
			return;
		}*/
		//Move these lines outside the function so we only have to call them once.
        //bm.GetComponent<BattleMapCreation>().Matrix[y][x].GetComponent<SpriteRenderer>().sprite = blue;
		Debug.Log ("Square " + y + " " + x);
        //bm.GetComponent<BattleMapCreation>().Matrix[y][x].GetComponent<TileScript>().clickable = true;

        county++;
		if (county == moves) {
			Debug.Log ("0Mov");
			return;
		}
		Debug.Log ("Recursion started");
        FindNext(x + 1, y, county);
        FindNext(x - 1, y, county);
        FindNext(x, y - 1, county);
        FindNext(x, y + 1, county);
    }
}
