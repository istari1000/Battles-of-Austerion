﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//this will contain all armies, their units, and the units' stats
public class ArmyManagerController : MonoBehaviour
{
    private GameObject unitScript;
    private List<List<GameObject>> Matrixx;
    public List<List<GameObject>> unitsSide1;
    public List<List<GameObject>> unitsSide2;
    public List<List<GameObject>> unitsSide3;
    public GameObject UnitPrefab;
    public List<Node1> encyclopedia;
    public Ray ray;
    private int MatrixX;
    private int MatrixY;
    public RaycastHit2D hitbox;
    public Vector3 mousePosition, cameraPosition;
    public Vector2 rayVector;
    public Sprite blue, red, green, black, darkgreen;
    public bool placementPhase, movementPhase, ppended;
    public int encCounter;
    public bool LetMoveHappen;  //allows this function to change to movement phase after battlemapcreation changes tiles to green
    private GameObject battleMap;
	public int countss;//count through units to create unique names

    // Use this for initialization
    void Start()
    {
		countss = 0;
        LetMoveHappen = false;
        ppended = false;
        unitScript = GameObject.Find("BattleMapCreation");
        battleMap = GameObject.Find("BattleMapCreation");
        encCounter = 0;
        placementPhase = false;
        movementPhase = false;
        Matrixx = battleMap.GetComponent<BattleMapCreation>().Matrix;
        //demo 3 units with move 3, 5, 7
        encyclopedia = new List<Node1>();
        Node1 unit1 = new Node1(3);
        encyclopedia.Add(unit1);
        Node1 unit2 = new Node1(4);
        encyclopedia.Add(unit2);
        Node1 unit3 = new Node1(5);
        encyclopedia.Add(unit3);

    }
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
    // Update is called once per frame
    void Update()
    {//placement phase
        if (placementPhase && Input.GetMouseButtonDown(0))
        {//places units where the mouse clicks

            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			Debug.Log (Input.mousePosition);
			//cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
            if (hitbox)
            {//
                GameObject temp = GameObject.Find(hitbox.collider.gameObject.name);
                Debug.Log(temp.GetComponent<TileScript>().clickable);
				Debug.Log(temp.name);
                bool tempClickable = temp.GetComponent<TileScript>().clickable;
                if (tempClickable == true)
                {
                    temp.GetComponent<TileScript>().clickable = false;
                    temp.GetComponent<SpriteRenderer>().sprite = green;
					GameObject unit = (GameObject)Instantiate(UnitPrefab, temp.transform.position, temp.transform.rotation);
                    unit.transform.parent = temp.transform;
					unit.name = "UNIT" + countss;
					countss++;
                    int move = encyclopedia[encCounter].moves;
					unit.GetComponent<UnitsScript> ().moves = move;
                    encCounter++;//needs to be expanded
                    if (encCounter >= encyclopedia.Count && LetMoveHappen)
                    {
                        LetMoveHappen = false;
                        Debug.Log("Got Here");
						ChangePhaseToMove();
                        ppended = true;
                    }
                }
            }
            
            
        }
		if (movementPhase == true && ppended == false)
        {
			countss = 0;
            if (Input.GetMouseButtonDown(0))
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
				if (hitbox)
                {
					GameObject temp = GameObject.Find(hitbox.collider.gameObject.name);
					if(temp.tag == "Unit"){
						int xValue = temp.transform.parent.GetComponent<TileScript> ().getX ();
						int yValue = temp.transform.parent.GetComponent<TileScript> ().getY ();
						int county = 0;
						Debug.Log ("X: " + xValue + " Y: " + yValue);
						temp.GetComponent<UnitsScript> ().FindNext (yValue, xValue, county);
					}
					//Debug.Log ("THIS" + temp.name);
                }
            }
        }
        if (movementPhase == true && ppended == true)
        {
            ppended = false;
            for (int i = 18; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {	//sets starting blue area back to green
                    battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = green;
                    battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = false;
                }
            }
        }
    }
    IEnumerator Wait(KeyCode keycode)
    {
        while (!Input.GetKeyDown(keycode))
            yield return null;
    }
    void ChangePhaseToMove()
    {
        placementPhase = false;
        movementPhase = true;
    }

	void debugger()
	{
		Debug.Log ("Received input down");
	}
}
