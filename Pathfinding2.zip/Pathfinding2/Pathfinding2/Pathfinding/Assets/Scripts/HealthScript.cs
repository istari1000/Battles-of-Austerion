﻿using UnityEngine;
using System.Collections;

public class HealthScript : MonoBehaviour {
	public Sprite FullHealth, SFHealth, FTHealth, TFHealth, NoHealth;
	public float healthPercentage;
	// Use this for initialization
	void Start () {
		healthPercentage = 1f;
		gameObject.GetComponent<SpriteRenderer> ().sprite = FullHealth;
	}
	
	// Update is called once per frame
	void Update () {
		healthPercentage = (float)transform.parent.GetComponent<UnitsScript> ().currentHealth / (float)transform.parent.GetComponent<UnitsScript> ().totalHealth;
		if(healthPercentage == 1f)
			gameObject.GetComponent<SpriteRenderer> ().sprite = FullHealth;
		else if(healthPercentage >= .75f)
			gameObject.GetComponent<SpriteRenderer> ().sprite = SFHealth;
		else if(healthPercentage >= .50f)
			gameObject.GetComponent<SpriteRenderer> ().sprite = FTHealth;
		else if(healthPercentage >= .25f)
			gameObject.GetComponent<SpriteRenderer> ().sprite = TFHealth;
		else if(healthPercentage >= 0f)
			gameObject.GetComponent<SpriteRenderer> ().sprite = NoHealth;
	}
}
