﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SearchForSquaresToMove : MonoBehaviour {
    int counter;
	// Use this for initialization
	void Start () {
        counter = 0;
	}
	
	// Update is called once per frame
	void Update () {
	    
	}
    void FindNext()
    {
        if (counter != 6)
        {
            counter++;

        }
    }
}
