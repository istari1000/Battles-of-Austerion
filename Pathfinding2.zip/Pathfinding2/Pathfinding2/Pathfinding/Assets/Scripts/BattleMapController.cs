﻿using UnityEngine;
using System.Collections;

public class BattleMapController : MonoBehaviour {

    //public GameObject[] unitListSide1;
    //public GameObject[] unitListSide2;
    //for now use square as unit - pls change
    public GameObject unit;
    //public Map map;//which map to use
    public GameObject mapGroup;
	// Use this for initialization
	void Start () {
        unit = GameObject.Find("Square");
        //GameObject temp = Instantiate(unit,)
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
