﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class UnitsScript : MonoBehaviour {
    public int moves;
    public int currentMoves;
    public int counter;
    public int MatrixY;
    public int MatrixX;
	public int faction;
	public int type;
	public int range;
	public float timeCheck;
    public Sprite blue, red, green, darkgreen, brown;
    private GameObject armyManagerController;
    private GameObject bm;
    public Ray ray;
    public RaycastHit2D hitbox;
	public List<Node> beenTo;
	public Node add;
	public int ct;
	public bool isAttackable;
	public Text healthText; 
	public Slider healthSlider;
	public Text statText;
	//Unit stats
	public int totalHealth, currentHealth, noOfUnits, healthPerUnit, frontLineSize;
	public int noOfDice, dieSize;
	public bool hasAttacked;
	// Use this for initialization

	void Start () {
        armyManagerController = GameObject.Find("ArmyManagerController");
        counter = 0;
		isAttackable = false;
		hasAttacked = false;

        bm = GameObject.Find("BattleMapCreation");
		if (type == 0) {							//Swordsman
			totalHealth = 30;
			currentHealth = 30;
			noOfUnits = 15;
			healthPerUnit = 2;
			frontLineSize = 10;
			noOfDice = 2;
			dieSize = 4;
			range = 2;
			moves = 4;
		} else if (type == 1) {						//Spearman
			totalHealth = 30;
			currentHealth = 30;
			noOfUnits = 15;
			healthPerUnit = 2;
			frontLineSize = 5;
			noOfDice = 1;
			dieSize = 4;
			range = 2;
			moves = 3;
		} else if (type == 2) {						//Archer
			totalHealth = 10;
			currentHealth = 10;
			noOfUnits = 10;
			healthPerUnit = 1;
			frontLineSize = 10;
			noOfDice = 1;
			dieSize = 6;
			range = 4;
			moves = 5;
		}

		currentMoves = moves;

	}
	
	// Update is called once per frame
	void Update () {
        /*if (Input.GetMouseButtonDown(0))
        {
            //            cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
            if (armyManagerController.GetComponent<ArmyManagerController>().movementPhase)
            {

                MatrixX = (int)(transform.parent.position.x / 5);
                MatrixY = (int)(transform.parent.position.y / 5);
                Debug.Log(MatrixX + " HAHA" + MatrixY);
                FindNext(MatrixX, MatrixY, counter);
            }
        }*/
    }

	//Turning this into a 2d list that saves the sqaures that we need to turn blue so we can do them all at once somewhere else.
    public void FindNext(int x, int y, int county)
    {
		

		if (x > 19 || x < 0 || y > 19 || y < 0) {
			return;
		}

		if (county == currentMoves) {
			return;
		}

		if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().movesLeft < (moves - county))
			bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().movesLeft = (moves - county);
		else
			return;


		/*if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().isPassable == false) {
			Debug.Log ("ImpTer");
			return;
		}*/
		//Move these lines outside the function so we only have to call them once.
        bm.GetComponent<BattleMapCreation>().Matrix[y][x].GetComponent<SpriteRenderer>().sprite = blue;

        bm.GetComponent<BattleMapCreation>().Matrix[y][x].GetComponent<TileScript>().clickable = true;
        county++;


        FindNext(x + 1, y, county);
        FindNext(x - 1, y, county);
        FindNext(x, y - 1, county);
        FindNext(x, y + 1, county);
    }

	//Finds available attacking squares
	public void FindAttack(int x, int y, int rangeCounter)
	{
		if (x > 19 || x < 0 || y > 19 || y < 0) {
			return;
		}

		if (range == rangeCounter) {
			return;
		}

		if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().movesLeft < (range - rangeCounter))
			bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().movesLeft = (range - rangeCounter);
		else
			return;


		/*if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().isPassable == false) {
			Debug.Log ("ImpTer");
			return;
		}*/
		bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<SpriteRenderer> ().sprite = red;

		if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().transform.childCount != 0 && faction != bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().GetComponentInChildren<UnitsScript> ().faction) {
			bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().clickable = true;
			bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().GetComponentInChildren<UnitsScript> ().isAttackable = true;
		}
			rangeCounter++;

		FindAttack(x + 1, y, rangeCounter);
		FindAttack(x - 1, y, rangeCounter);
		FindAttack(x, y - 1, rangeCounter);
		FindAttack(x, y + 1, rangeCounter);
	}
}
