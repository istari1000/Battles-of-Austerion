﻿using UnityEngine;
using System.Collections.Generic;

public class Node {

	public int x;
	public int y;

	public void Clear(){
	}

	public Node(){
		x = -1;
		y = -1;
	}

	public int getX(){
		return x;
	}

	public int getY(){
		return y;
	}
}
