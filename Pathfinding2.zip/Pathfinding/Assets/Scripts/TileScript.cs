﻿using UnityEngine;
using System.Collections;

public class TileScript : MonoBehaviour {
    public int move;
    public bool clickable;
    public bool isPassable;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
