﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BattleMapCreation : MonoBehaviour {
    public List<List<GameObject>> Matrix;
    public GameObject UnitPrefab;
    public GameObject GrassTilePrefab;
    public GameObject ForestTilePrefab;
    public GameObject MountainTilePrefab;
    private GameObject armyManagerController;
    public Ray ray;
        public RaycastHit2D hitbox;

    public Sprite blue, red, green, brown, darkgreen;

    float xPos = 0;
    float yPos = 0;
    // Use this for initialization
    void Start() {
        Matrix = new List<List<GameObject>>();
        armyManagerController = GameObject.Find("ArmyManagerController");
        for (int i = 0; i < 20; i++)
        {
            Matrix.Add(new List<GameObject>());
        }
        int counts = 0;
        for (xPos = 0; xPos < 60; xPos += 3)
        {
            for (yPos = 0; yPos < 60; yPos += 3)
            {//instantiates tiles and adds them to matrix
                GameObject tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos, yPos), Quaternion.identity);
                tile.name = "tile" + counts;
                counts++;
                Matrix[(int)(xPos / 3)].Add(tile);
            }
        }


        for (int i = 18; i < 20; i++)
        {
            for (int j = 0; j < 20; j++)
            {
                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
        armyManagerController.GetComponent<ArmyManagerController>().placementPhase = true;
        armyManagerController.GetComponent<ArmyManagerController>().LetMoveHappen = true;

    }

    // Update is called once per frame
    void Update () {
        
	}
}
