﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartController : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }

    // Update is called once per frame
    void Update () {
        if (SceneManager.GetActiveScene().buildIndex == 0)//start scene
        {
            if (Input.GetMouseButtonDown(0))
                SceneManager.LoadScene(1);
        }
        if (SceneManager.GetActiveScene().buildIndex == 1)//faction selection scene
        {

        }
        if(SceneManager.GetActiveScene().buildIndex == 2)//world scene
        {

        }
        if (SceneManager.GetActiveScene().buildIndex == 3)//battle
        {

        }
        if (SceneManager.GetActiveScene().buildIndex == 4)//victory scene
        {

        }
    }
}
