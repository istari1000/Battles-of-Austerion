﻿using UnityEngine;
using System.Collections;

public class CityScript : MonoBehaviour {
    public int gold;
    public int production;
    public string cityName;
    public int faction;
	// Use this for initialization
	void Start () {
        gold = 0;
        production = 10;//all cities start with 10 a turn for now
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
