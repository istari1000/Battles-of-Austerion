﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CityScript : MonoBehaviour {
    public Sprite darkBrown, darkRed;
    public int gold;
    public int production;
    public string cityName;
    public int faction;
    public bool isCity;
    public int xPos, yPos;
    public bool isOccupied;
    public Ray ray;
    public RaycastHit2D hitbox;
    public bool clickable;
    GameObject tempTile;
    GameObject wm;
	// Use this for initialization
	void Start () {
        wm = GameObject.Find("WorldManagerController");
        if (isCity)
        {
            GetComponent<SpriteRenderer>().sprite = darkRed;
            
        }
        else
        {
            GetComponent<SpriteRenderer>().sprite = darkBrown;
        }
        clickable = false;
	}
	
	// Update is called once per frame
	void Update () {

	}
    void OnMouseDown()
    {
        /*if (isCity && faction == wm.GetComponent<WorldMapController>().currentFaction)
        {
            //recruit
        }
        else if(clickable)
        {
            //move if possible
        }*/
    }
    

}
