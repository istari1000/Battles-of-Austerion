﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class TempArmy : MonoBehaviour {

    public List<Node1> encyclopedia;
    public Sprite brown, red;
    public int faction;
    GameObject wm;//world manager
	// Use this for initialization
	void Start () {
        wm = GameObject.Find("WorldMapController");
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0) && wm.GetComponent<WorldMapController>().currentFaction == faction)
        {

        }
	}
    public void moveUnit(GameObject unit, Vector3 goal)
    {
        unit.transform.position = goal;

    }
    public void FindNext(int x, int y, int county)
    {


        if (x > 2 || x < 0 || y > 2 || y < 0)
        {
            return;
        }

        if (county == 1)
        {
            return;
        }



        /*if (bm.GetComponent<BattleMapCreation> ().Matrix [y] [x].GetComponent<TileScript> ().isPassable == false) {
			Debug.Log ("ImpTer");
			return;
		}*/
        //Move these lines outside the function so we only have to call them once.
        wm.GetComponent<WorldMapController>().cityList[y][x].GetComponent<CityScript>().clickable = true;
        county++;


        FindNext(x + 1, y, county);
        FindNext(x - 1, y, county);
        FindNext(x, y - 1, county);
        FindNext(x, y + 1, county);
    }
}
