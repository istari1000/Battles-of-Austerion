﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//this will contain all armies, their units, and the units' stats
public class ArmyManagerController : MonoBehaviour
{
    private List<List<GameObject>> Matrixx;
    public List<List<GameObject>> unitsSide1;
    public List<List<GameObject>> unitsSide2;
    public List<List<GameObject>> unitsSide3;
    public List<Node1> encyclopedia;
    public List<GameObject> unitList;
    public GameObject UnitPrefab;
    public Ray ray;
    private int MatrixX;
    private int MatrixY;
    public RaycastHit2D hitbox;
    public Vector3 mousePosition, cameraPosition;
    public Vector2 rayVector;
    public Sprite blue, red, green, black, darkgreen;
    public bool placementPhase, movementPhase, ppended, playerTurn, factionSwitched, isAttacking, attack;
    public bool playerWin, enemyWin;
    public bool gamePause;
    public int currentFaction;
    public int encCounter;
    public bool LetMoveHappen;  //allows this function to change to movement phase after battlemapcreation changes tiles to green
    private GameObject battleMap;
    public int countss;//count through units to create unique names
    public bool unitClicked;
    private GameObject tempTile;
    private GameObject tempUnit;
    private GameObject tempEnemy;
    public Text typeText;
    public Text statText;

    // Use this for initialization
    void Start()
    {
        if (typeText == null) { Debug.LogError("No Text component attached!"); return; }
        countss = 0;
        factionSwitched = false;
        LetMoveHappen = false;
        ppended = false;
        battleMap = GameObject.Find("BattleMapCreation");
        encCounter = 0;
        placementPhase = false;
        movementPhase = false;
        unitClicked = false;
        isAttacking = false;
        attack = false;
        playerTurn = true;
        playerWin = false;
        enemyWin = false;
        gamePause = false;
        currentFaction = 0;
        Matrixx = battleMap.GetComponent<BattleMapCreation>().Matrix;
        typeText.text = "";
        statText.text = "";
        //demo 3 units with move 3, 5, 7
        //Temporarily populates encyclopedia, until game manager and world overview are created.
        encyclopedia = new List<Node1>();
        for (int ctF = 0; ctF < 2; ctF++)
        {
            for (int ctT = 0; ctT < 3; ctT++)
            {
                for (int ctC = 0; ctC < 3; ctC++)
                {
                    Node1 unit1 = new Node1(ctF, ctT);
                    encyclopedia.Add(unit1);
                }
            }

        }


    }
    void Awake()
    {
        //DontDestroyOnLoad(transform.gameObject);
    }
    // Update is called once per frame
    void Update()
    {//placement phase
        if (playerWin)
        {
            //player wins battle
            SceneManager.LoadScene("Victory");
        }
        if (enemyWin)
        {
            //enemy wins
            SceneManager.LoadScene("Victory");
        }
        if (!gamePause)
        {
            if (placementPhase && Input.GetMouseButtonDown(0))
            {//places units where the mouse clicks

                if (encyclopedia[encCounter].faction == 1 && !factionSwitched)
                {
                    resetMap();
                    for (int i = 0; i < 2; i++)
                    {
                        for (int j = 0; j < 20; j++)
                        {   //sets starting blue area back to green
                            battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                            battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
                        }
                    }
                    factionSwitched = true;
                }
                else
                {
                    placeUnit();
                }

            }
            if (movementPhase == true && ppended == false)
            {
                countss = 0;
                if (Input.GetMouseButtonDown(0) && !unitClicked)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempUnit = GameObject.Find(hitbox.collider.gameObject.name);
                        if (tempUnit.tag == "Unit" && tempUnit.GetComponent<UnitsScript>().faction == currentFaction)
                        {
                            int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                            int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                            int county = 0;
                            tempUnit.GetComponent<UnitsScript>().FindNext(yValue, xValue, county);
                            unitClicked = true;
                            updateUI(tempUnit);
                        }
                        else if (tempUnit.tag == "EndTurn")
                        {
                            foreach (GameObject unit in unitList)
                            {
                                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                                unit.GetComponent<UnitsScript>().hasAttacked = false;
                            }
                            if (currentFaction == 0)
                                currentFaction = 1;
                            else
                                currentFaction = 0;
                        }
                    }
                }
                else if (Input.GetMouseButtonDown(0) && unitClicked && !isAttacking && !attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                        if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().clickable)
                        {
                            tempUnit.transform.parent = tempTile.transform;
                            StartCoroutine(moveUnit(tempUnit, tempTile.transform.position));
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else if (tempTile.name == tempUnit.name)
                        {
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else
                        {
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        resetMap();
                    }
                }
                else if (isAttacking && !tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                    int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                    tempUnit.GetComponent<UnitsScript>().FindAttack(yValue, xValue, 0);
                    isAttacking = false;
                    attack = true;

                }
                else if (Input.GetMouseButtonDown(0) && attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempEnemy = GameObject.Find(hitbox.collider.gameObject.name);
                        if (tempEnemy.tag == "Unit" && tempEnemy.GetComponent<UnitsScript>().isAttackable)
                        {
                            Attack(tempUnit, tempEnemy);

                        }
                        tempUnit.GetComponent<UnitsScript>().hasAttacked = true;
                        foreach (GameObject unit in unitList)
                            unit.GetComponent<UnitsScript>().isAttackable = false;
                        attack = false;
                        unitClicked = false;
                        updateUI(tempUnit);
                        resetMap();

                    }
                }
            }
            if (movementPhase == true && ppended == true)
            {
                ppended = false;
                resetMap();
            }
        }
        gamePause = true;
        StartCoroutine(stopBreakingTheGame());
    }
    IEnumerator Wait(KeyCode keycode)
    {
        while (!Input.GetKeyDown(keycode))
            yield return null;
    }
    void ChangePhaseToMove()
    {
        placementPhase = false;
        movementPhase = true;
    }

    void resetMap()
    {
        for (int i = 0; i < 20; i++)
        {
            for (int j = 0; j < 20; j++)
            {   //sets starting blue area back to green
                battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = green;
                battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = false;
                battleMap.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().movesLeft = 0;

            }
        }
    }

    IEnumerator moveUnit(GameObject Unit, Vector3 Goal)
    {
        while (Unit.transform.position != Goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, Goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
    }
    void debugger()
    {
        Debug.Log("Received input down");
    }

    void Attack(GameObject attacker, GameObject attackee)
    {

        int diceRoll = 0;
        float damageDealt;

        for (int ct = 0; ct < attacker.GetComponent<UnitsScript>().noOfDice; ct++)
        {
            diceRoll += Random.Range(1, attacker.GetComponent<UnitsScript>().dieSize);
        }

        damageDealt = diceRoll;

        if (attacker.GetComponent<UnitsScript>().noOfUnits < attacker.GetComponent<UnitsScript>().frontLineSize)
        {
            damageDealt = (int)(damageDealt * ((float)attacker.GetComponent<UnitsScript>().noOfUnits / (float)attacker.GetComponent<UnitsScript>().frontLineSize));
        }

        int unitDeath = (int)Mathf.Floor(damageDealt / attackee.GetComponent<UnitsScript>().healthPerUnit);

        if (unitDeath > attackee.GetComponent<UnitsScript>().frontLineSize && attackee.GetComponent<UnitsScript>().noOfUnits > attackee.GetComponent<UnitsScript>().frontLineSize)
        {
            unitDeath = attackee.GetComponent<UnitsScript>().frontLineSize;
            damageDealt = unitDeath * attackee.GetComponent<UnitsScript>().healthPerUnit;
        }

        if (damageDealt < 1)
            damageDealt = 1;
        attackee.GetComponent<UnitsScript>().currentHealth -= (int)damageDealt;
        attackee.GetComponent<UnitsScript>().noOfUnits -= unitDeath;

        if (attackee.GetComponent<UnitsScript>().currentHealth <= 0)
            attackee.GetComponent<UnitsScript>().currentHealth = 0;

        if (attackee.GetComponent<UnitsScript>().currentHealth == 0)
            StartCoroutine(Death(attackee));
        else
            StartCoroutine(Damage(attackee));

    }

    IEnumerator Damage(GameObject Damaged)
    {
        for (int ct = 0; ct < 4; ct++)
        {
            Damaged.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.1f);
            Damaged.GetComponent<SpriteRenderer>().sprite = black;
            yield return new WaitForSeconds(.1f);

        }
    }

    IEnumerator stopBreakingTheGame()
    {
        yield return new WaitForSeconds(1f);
        gamePause = false;
    }


    IEnumerator Death(GameObject Dying)
    {
        for (int ct = 0; ct < 2; ct++)
        {
            Dying.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.3f);
            Dying.GetComponent<SpriteRenderer>().sprite = black;
            yield return new WaitForSeconds(.3f);

        }
        //kill unit
        unitList.Remove(Dying);
        Destroy(Dying);
        enemyWin = true;
        playerWin = true;
        //if no units left of a faction, other faction wins
        foreach (GameObject unit in unitList)
        {
            if (unit.GetComponent<UnitsScript>().faction == 0)
                enemyWin = false;
            if (unit.GetComponent<UnitsScript>().faction == 1)
                playerWin = false;
        }
    }

    void updateUI(GameObject current)
    {
        if (unitClicked)
        {
            if (current.GetComponent<UnitsScript>().type == 0)
                typeText.text = "Swordsman";
            if (current.GetComponent<UnitsScript>().type == 1)
                typeText.text = "Spearman";
            if (current.GetComponent<UnitsScript>().type == 2)
                typeText.text = "Archer";
            statText.text = "Health: " + current.GetComponent<UnitsScript>().currentHealth + "\nUnits: " + current.GetComponent<UnitsScript>().noOfUnits + "\nHPU: " + current.GetComponent<UnitsScript>().healthPerUnit
            + "\nFront Line: " + current.GetComponent<UnitsScript>().frontLineSize + "\nDamage: " + current.GetComponent<UnitsScript>().dieSize + "\nDice: " + current.GetComponent<UnitsScript>().noOfDice +
            "\nMove: " + current.GetComponent<UnitsScript>().moves + "\nRange: " + current.GetComponent<UnitsScript>().range;
        }
        else
        {
            typeText.text = "";
            statText.text = "";
        }

    }
    void placeUnit()
    {
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
        if (hitbox)
        {//
            tempTile = GameObject.Find(hitbox.collider.gameObject.name);
            bool tempClickable = tempTile.GetComponent<TileScript>().clickable;
            if (tempClickable == true)
            {
                tempTile.GetComponent<TileScript>().clickable = false;
                tempTile.GetComponent<SpriteRenderer>().sprite = green;
                GameObject unit = (GameObject)Instantiate(UnitPrefab, tempTile.transform.position, tempTile.transform.rotation);
                unit.transform.parent = tempTile.transform;
                unit.name = "UNIT" + countss;
                countss++;
                int faction = encyclopedia[encCounter].faction;
                int type = encyclopedia[encCounter].type;
                unit.GetComponent<UnitsScript>().faction = faction;
                unit.GetComponent<UnitsScript>().type = type;
                unitList.Add(unit);

                encCounter++;//needs to be expanded
                if (encCounter >= encyclopedia.Count && LetMoveHappen)
                {
                    LetMoveHappen = false;
                    ChangePhaseToMove();
                    resetMap();
                }
            }
        }
    }
}
