﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FactionSelectionController : MonoBehaviour {

    public Ray ray;
    public RaycastHit2D hitbox;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
            if (hitbox)
            {
                //faction selection here
            }
        }
    }
}
