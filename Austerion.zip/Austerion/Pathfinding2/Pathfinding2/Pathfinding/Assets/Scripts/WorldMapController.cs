﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class WorldMapController : MonoBehaviour
{
    public GameObject mapTile, army;
    GameObject sword, spear, archer;
    GameObject tempTile, XB, goalTile, tempArmy, endTurnWM;
    Ray ray;
    RaycastHit2D hitbox;
    int count;
    public int currentFaction;
    public bool inRecruitment, somethingSelected, justRecruited, showMove, allowMove;
    public bool inAnimation, inBattle;
    public GameObject RecruitButton, X, EndTurn;
    public List<GameObject> armies;//list of armies
    public List<List<GameObject>> cityList;//list of region tiles
                                           // Use this for initialization
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
    void Start()
    {//create regions
        inAnimation = false;
        justRecruited = false;
        inRecruitment = false;
        somethingSelected = false;
        showMove = false;
        allowMove = false;
        cityList = new List<List<GameObject>>();
        count = 0;
        for (int i = 0; i < 3; i++)
        {
            cityList.Add(new List<GameObject>());
            for (int j = 0; j < 3; j++)
            {
                GameObject tile = (GameObject)Instantiate(mapTile, new Vector2(i * 10, j * 10), Quaternion.identity);
                tile.name = "Region" + count;
                count++;
                if (i == 0 && j == 0)
                {//player 0 city
                    tile.GetComponent<CityScript>().faction = 0;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                }
                if (i == 2 && j == 2)
                {//player 1 city
                    tile.GetComponent<CityScript>().faction = 1;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                }
                tile.GetComponent<CityScript>().xPos = i;
                tile.GetComponent<CityScript>().yPos = j;
                cityList[i].Add(tile);
            }
        }
        endTurnWM = (GameObject)Instantiate(EndTurn, new Vector3(20, -10, -1), Quaternion.identity);
        currentFaction = 0;
        //add end turn button
    }

    // Update is called once per frame
    void Update()
    {
        if (inAnimation == false && inBattle == false)
        {
            if (inRecruitment == false && somethingSelected == false && showMove == false && allowMove == false && Input.GetMouseButtonDown(0))
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                if (hitbox)
                {
                    tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                    //if you click on your faction's city, go into recruitment
                    if (tempTile.tag == "EndTurn")
                        endTurn();
                    else if (tempTile.GetComponent<CityScript>().isCity && currentFaction == tempTile.GetComponent<CityScript>().faction)
                    {
                        tempTile.GetComponent<CityScript>().selected = true;
                        somethingSelected = true;
                        inRecruitment = true;
                        XB = (GameObject)Instantiate(X, new Vector3(15, 25, -1), Quaternion.identity);  //leave recruitment
                        archer = (GameObject)Instantiate(RecruitButton, new Vector3(10, 0, -1), Quaternion.identity);
                        sword = (GameObject)Instantiate(RecruitButton, new Vector3(10, 10, -1), Quaternion.identity);
                        spear = (GameObject)Instantiate(RecruitButton, new Vector3(10, 20, -1), Quaternion.identity);
                        archer.GetComponent<RecruitmentButton>().type = 2;
                        sword.GetComponent<RecruitmentButton>().type = 0;
                        spear.GetComponent<RecruitmentButton>().type = 1;
                        archer.transform.parent = tempTile.transform;
                        sword.transform.parent = tempTile.transform;
                        spear.transform.parent = tempTile.transform;
                        XB.transform.parent = tempTile.transform;
                        //recruit in a city
                    }//else if you select an army in your faction not on a city
                    else if (tempTile.GetComponent<CityScript>().isCity == false && tempTile.GetComponent<CityScript>().isOccupied == true && tempTile.GetComponentInChildren<ArmyManagerController>().faction == currentFaction && tempTile.GetComponentInChildren<ArmyManagerController>().hasMoved == false)
                    {
                        somethingSelected = true;
                        showMove = true;
                        int x = tempTile.GetComponent<CityScript>().xPos;
                        int y = tempTile.GetComponent<CityScript>().yPos;
                        MapMove(x, y);
                    }
                }
            }
            else if (allowMove == true && Input.GetMouseButtonDown(0))
            {
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                if (hitbox)
                {
                    goalTile = GameObject.Find(hitbox.collider.gameObject.name);
                    //move army
                    if (goalTile.tag != "EndTurn" && goalTile.GetComponent<CityScript>().clickable)
                    {
                        tempTile.GetComponent<CityScript>().isOccupied = false;
                        tempTile.GetComponent<CityScript>().hasArmy = false;
                        allowMove = false;
                        ResetMap();
                        tempArmy = tempTile.GetComponentInChildren<ArmyManagerController>().gameObject;
                        StartCoroutine(moveArmy(tempArmy, goalTile));
                        tempArmy.transform.parent = goalTile.transform;
                        Debug.Log("ISOCC");

                    }
                    else if (goalTile.tag != "EndTurn" && goalTile.GetComponent<CityScript>().selected)
                    {
                        goalTile.GetComponent<CityScript>().selected = false;
                        allowMove = false;
                        somethingSelected = false;
                        ResetMap();
                    }

                }
            }
            else if (justRecruited)//just recruited and army hasn't moved yet
            {
                int x = tempTile.GetComponent<CityScript>().xPos;
                int y = tempTile.GetComponent<CityScript>().yPos;
                if (tempTile.GetComponent<CityScript>().hasArmy)
                    MapMove(x, y);
                else
                    somethingSelected = false;
                justRecruited = false;
            }

        }
    }
    IEnumerator moveArmy(GameObject Unit, GameObject Goal)
    {
        inAnimation = true;
        Vector3 goal = Goal.transform.position;
        while (Unit.transform.position != goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        somethingSelected = false;
        inAnimation = false;
        //if you move into an occupied space
        if (Goal.GetComponent<CityScript>().isOccupied)
        {
            //if friendly, merge armies
            GameObject temp = Goal.GetComponentInChildren<ArmyManagerController>().gameObject;
            if (temp.GetComponent<ArmyManagerController>().faction == currentFaction)
            {
                foreach (Node1 node in temp.GetComponent<ArmyManagerController>().encyclopedia)
                    Unit.GetComponent<ArmyManagerController>().encyclopedia.Add(node);
                Destroy(temp);
                //merge
            }
            else
            {
                //fight
                temp.tag = "DEFENDER";
                Unit.tag = "ATTACKER";
                inBattle = true;
                SceneManager.LoadScene(3);
            }
        }
        Goal.GetComponent<CityScript>().isOccupied = true;
        Goal.GetComponent<CityScript>().hasArmy = true;
        Unit.GetComponent<ArmyManagerController>().hasMoved = true;
        Debug.Log(Unit.GetComponent<ArmyManagerController>().encyclopedia.Count);
    }
    public void MapMove(int x, int y)
    {
        //directions are dont go: 0 - left; 1 - right; 2 - up; 3 - down	
        if (x + 1 < 3)
        {
            cityList[x + 1][y].GetComponent<SpriteRenderer>().sprite = cityList[x + 1][y].GetComponent<CityScript>().blue;
            cityList[x + 1][y].GetComponent<CityScript>().clickable = true;
        }
        if (x - 1 > -1)
        {
            cityList[x - 1][y].GetComponent<SpriteRenderer>().sprite = cityList[x - 1][y].GetComponent<CityScript>().blue;
            cityList[x - 1][y].GetComponent<CityScript>().clickable = true;
        }
        if (y + 1 < 3)
        {
            cityList[x][y+1].GetComponent<SpriteRenderer>().sprite = cityList[x][y+1].GetComponent<CityScript>().blue;
            cityList[x][y + 1].GetComponent<CityScript>().clickable = true;
        }
        if (y - 1 > -1)
        {
            cityList[x][y - 1].GetComponent<SpriteRenderer>().sprite = cityList[x][y - 1].GetComponent<CityScript>().blue;
            cityList[x][y - 1].GetComponent<CityScript>().clickable = true;
        }
        showMove = false;
        allowMove = true;
    }
    public void ResetMap()
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if (i == 0 && j == 0)
                {
                    cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkBlue;
                }
                else if (i == 2 && j == 2)
                {
                    cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkRed;

                }
                else
                {
                    cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkBrown;
                }
                cityList[i][j].GetComponent<CityScript>().clickable = false;
                cityList[i][j].GetComponent<CityScript>().selected = false;
            }
        }
    }
    public void LeaveRecruitment()
    {
        Debug.Log("X");
        inRecruitment = false;
        justRecruited = true;
        Destroy(archer);
        Destroy(sword);
        Destroy(spear);
        Destroy(XB);
    }
    void endTurn()
    {
        if (inAnimation == false && somethingSelected == false)
        {
            if (currentFaction == 0)
                currentFaction = 1;
            else if (currentFaction == 1)
                currentFaction = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (cityList[i][j].GetComponent<CityScript>().isCity)
                        cityList[i][j].GetComponent<CityScript>().gold += cityList[i][j].GetComponent<CityScript>().production / 2;
                    if (cityList[i][j].GetComponent<CityScript>().isOccupied)
                        cityList[i][j].GetComponentInChildren<ArmyManagerController>().hasMoved = false;
                }
            }
        }
    }
}