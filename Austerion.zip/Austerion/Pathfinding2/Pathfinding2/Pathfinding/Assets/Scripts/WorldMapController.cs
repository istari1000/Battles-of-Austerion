﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class WorldMapController : MonoBehaviour
{

    public GameObject mapTile;
    GameObject tempTile;
    Ray ray;
    RaycastHit2D hitbox;
    int count;
    public int currentFaction;
    public GameObject army;
    public List<GameObject> armies;//list of armies
    public List<List<GameObject>> cityList;//list of region tiles
                                           // Use this for initialization
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
    void Start()
    {
        cityList = new List<List<GameObject>>();
        count = 0;
        for (int i = 0; i < 3; i++)
        {
            cityList.Add(new List<GameObject>());
            for (int j = 0; j < 3; j++)
            {
                GameObject tile = (GameObject)Instantiate(mapTile, new Vector2(i * 10, j * 10), Quaternion.identity);
                tile.name = "Region" + count;
                count++;
                if (i == 0 && j == 0)
                {
                    tile.GetComponent<CityScript>().faction = 0;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                }
                if (i == 2 && j == 2)
                {
                    tile.GetComponent<CityScript>().faction = 1;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                }
                tile.GetComponent<CityScript>().xPos = i;
                tile.GetComponent<CityScript>().yPos = j;
                cityList[i].Add(tile);
            }
        }
        currentFaction = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
            if (hitbox)
            {
                tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                if (tempTile.GetComponent<CityScript>().isCity && currentFaction == tempTile.GetComponent<CityScript>().faction)
                {
                    //recruit
                }
                else if (tempTile.GetComponent<CityScript>().clickable)
                {
                    //tempTile.GetComponent<TempArmy>().FindNext(tempTile.GetComponent<TempArmy>().)
                }
            }
        }
    }
}