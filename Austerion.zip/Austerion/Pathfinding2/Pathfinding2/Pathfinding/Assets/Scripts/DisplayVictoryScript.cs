﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class DisplayVictoryScript : MonoBehaviour {

	public Text victoryText;
	public RaycastHit2D hitbox;
	public Ray ray;
	public GameObject temp;
	// Use this for initialization
	void Start () {
		bool playerWin = false;
		GameObject controller = GameObject.Find("BattleMapCreation");
		if(controller.GetComponent<BattleMapCreation>().playerWin)
			victoryText.text = "Congratulations Player One!!";
		else
			victoryText.text = "Congratulations Player Two!!";	
	}
		
	// Update is called once per frame
	void Update ()
    {
		if (Input.GetMouseButtonDown (0))
        {
			ray = Camera.main.ScreenPointToRay (Input.mousePosition);
			hitbox = Physics2D.Raycast (ray.origin, ray.direction, Mathf.Infinity);
			if (hitbox)
            {
				temp = GameObject.Find (hitbox.collider.gameObject.name);
				if (temp.tag == "Respawn")
					SceneManager.LoadScene ("BattleMapOverview");
			}
		}
	}
}