﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BattleMapCreation : MonoBehaviour {
    public List<List<GameObject>> Matrix;
    public GameObject UnitPrefab;
    public GameObject GrassTilePrefab;
    public GameObject ForestTilePrefab;
    public GameObject MountainTilePrefab;
    private GameObject wm, tempTile, tempUnit, tempEnemy;
    private GameObject army1, army2;
    private int countss, encCounter1, encCounter2;
    Ray ray;
    RaycastHit2D hitbox;
    public List<GameObject> unitList;
    public Text typeText;
    public Text statText;
    public bool placementPhase, movementPhase, ppended, playerTurn, factionSwitched, isAttacking, attack, unitClicked;
    public bool inAnimation, inRecursion;
    public bool playerWin, enemyWin, gamePause;
    public bool army1Placed, army2Placed;
    public Sprite blue, red, green, brown, darkgreen, black;
    private Sprite temp;
    public int currentFaction;
    float xPos = 0;
    float yPos = 0;
    // Use this for initialization
    void Start() {
        encCounter1 = 0;
        encCounter2 = 0;
        countss = 0;
        typeText.text = "";
        statText.text = "";
        army1Placed = false;
        army2Placed = false;
        playerWin = false;
        enemyWin = false;
        gamePause = false;
        factionSwitched = false;
        placementPhase = false;
        movementPhase = false;
        unitClicked = false;
        isAttacking = false;
        attack = false;
        playerTurn = true;
        ppended = false;
        inAnimation = false;
        inRecursion = false;
        currentFaction = 0;
        Matrix = new List<List<GameObject>>();
        wm = GameObject.Find("WorldMapController");
        for (int i = 0; i < 20; i++)
        {
            Matrix.Add(new List<GameObject>());
        }
        int counts = 0;
        for (xPos = 0; xPos < 200; xPos += 10)
        {
            for (yPos = 0; yPos < 200; yPos += 10)
            {//instantiates tiles and adds them to matrix
                GameObject tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                tile.name = "tile" + counts;
				tile.GetComponent<TileScript> ().setX ((int)xPos / 10);
				tile.GetComponent<TileScript> ().setY ((int)yPos / 10);
                counts++;
                Matrix[(int)(xPos / 10)].Add(tile);
            }
        }


        for (int i = 18; i < 20; i++)
        {
            for (int j = 0; j < 20; j++)
            {
                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
        placementPhase = true;
    }

    // Update is called once per frame
    void Update() {
        if (placementPhase && Input.GetMouseButtonDown(0))
        {
            placeUnit();
        }
        else if (army1Placed && army2Placed && placementPhase)
        {
            resetMap();
            placementPhase = false;
            movementPhase = true;
            currentFaction = 0;
        }
        else if (movementPhase)
        {

            //movement phase
            if (ppended == false && inAnimation == false && inRecursion == false)
            {

                if (Input.GetMouseButtonDown(0) && unitClicked == false && isAttacking)
                {
                    resetMap();
                    isAttacking = false;
                }
                else if (Input.GetMouseButtonDown(0) && unitClicked && tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    unitClicked = false;
                }
                else if (Input.GetMouseButtonDown(0) && !unitClicked)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempUnit = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempUnit.name);
                        if (tempUnit.tag == "Unit" && tempUnit.GetComponent<UnitsScript>().faction == currentFaction)
                        {
                            int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                            int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                            inRecursion = true;
                            FindNext(xValue, yValue, tempUnit);
                            inRecursion = false;
                            unitClicked = true;
                            updateUI(tempUnit);
                        }
                        else if (tempUnit.tag == "EndTurn")
                        {
                            resetMap();
                            foreach (GameObject unit in unitList)
                            {
                                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                                unit.GetComponent<UnitsScript>().hasAttacked = false;
                            }
                            if (currentFaction == 0)
                                currentFaction = 1;
                            else if (currentFaction == 1)
                                currentFaction = 0;
                        }
                    }
                }
                else if (Input.GetMouseButtonDown(0) && unitClicked && !isAttacking && !attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempTile.name);
                        if (tempUnit.GetComponent<UnitsScript>().hasAttacked)
                        {
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().clickable && tempTile.GetComponent<TileScript>().isOccupied == false)
                        {
                            tempUnit.transform.parent.GetComponent<TileScript>().isOccupied = false;
                            tempUnit.transform.parent = tempTile.transform;
                            tempTile.GetComponent<TileScript>().isOccupied = true;
                            StartCoroutine(moveUnit(tempUnit, tempTile.transform.position));
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else if (tempTile.name == tempUnit.name)
                        {
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else
                        {
                            resetMap();
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        resetMap();
                    }
                    else
                    {
                        resetMap();
                        unitClicked = false;
                    }
                }
                else if (isAttacking && !tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                    int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                    inRecursion = true;
                    float time = 0;
                    FindAttack(xValue, yValue, tempUnit);
                    time += Time.deltaTime;
                    Debug.Log(time);
                    inRecursion = false;
                    isAttacking = false;
                    attack = true;

                }
                else if (Input.GetMouseButtonDown(0) && attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempEnemy = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempEnemy.name);
                        if (tempEnemy.tag == "Unit" && tempEnemy.GetComponent<UnitsScript>().isAttackable)
                        {
                            Attack(tempUnit, tempEnemy);

                        }
                        tempUnit.GetComponent<UnitsScript>().hasAttacked = true;
                        foreach (GameObject unit in unitList)
                            unit.GetComponent<UnitsScript>().isAttackable = false;
                        attack = false;
                        unitClicked = false;
                        updateUI(tempUnit);
                        resetMap();

                    }
                    else
                    {
                        attack = false;
                        unitClicked = false;
                        resetMap();
                    }
                }

            }
            if (movementPhase == true && ppended == true)
            {
                countss = 0;
                ppended = false;
                resetMap();
            }
        }
        //if end turn pressed, switch factions
        if (playerWin)
        {
            //player wins battle
            army1.GetComponent<ArmyManagerController>().inBattle = false;
            Destroy(army2);
            wm.GetComponent<WorldMapController>().inBattle = false;
            SceneManager.LoadScene("Victory");
        }
        if (enemyWin)
        {
            //enemy wins
            Destroy(army1);
            army2.GetComponent<ArmyManagerController>().inBattle = false;
            wm.GetComponent<WorldMapController>().inBattle = false;
            SceneManager.LoadScene("Victory");
        }
    }
    void Attack(GameObject attacker, GameObject attackee)
    {

        int diceRoll = 0;
        float damageDealt;

        for (int ct = 0; ct < attacker.GetComponent<UnitsScript>().noOfDice; ct++)
        {
            diceRoll += Random.Range(1, attacker.GetComponent<UnitsScript>().dieSize);
        }

        damageDealt = diceRoll;

        if (attacker.GetComponent<UnitsScript>().noOfUnits < attacker.GetComponent<UnitsScript>().frontLineSize)
        {
            damageDealt = (int)(damageDealt * ((float)attacker.GetComponent<UnitsScript>().noOfUnits / (float)attacker.GetComponent<UnitsScript>().frontLineSize));
        }

        int unitDeath = (int)Mathf.Floor(damageDealt / attackee.GetComponent<UnitsScript>().healthPerUnit);

        if (unitDeath > attackee.GetComponent<UnitsScript>().frontLineSize && attackee.GetComponent<UnitsScript>().noOfUnits > attackee.GetComponent<UnitsScript>().frontLineSize)
        {
            unitDeath = attackee.GetComponent<UnitsScript>().frontLineSize;
            damageDealt = unitDeath * attackee.GetComponent<UnitsScript>().healthPerUnit;
        }

        if (damageDealt < 1)
            damageDealt = 1;
        attackee.GetComponent<UnitsScript>().currentHealth -= (int)damageDealt;
        attackee.GetComponent<UnitsScript>().noOfUnits -= unitDeath;

        if (attackee.GetComponent<UnitsScript>().currentHealth <= 0)
            attackee.GetComponent<UnitsScript>().currentHealth = 0;

        if (attackee.GetComponent<UnitsScript>().currentHealth == 0)
        {
            attackee.transform.parent.GetComponent<TileScript>().isOccupied = false;
            StartCoroutine(Death(attackee));
        }
        else
        {
            StartCoroutine(Damage(attackee));
        }

    }

    IEnumerator Damage(GameObject Damaged)
    {
        inAnimation = true;
        temp = Damaged.GetComponent<SpriteRenderer>().sprite;
        for (int ct = 0; ct < 4; ct++)
        {

            Damaged.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.1f);
            Damaged.GetComponent<SpriteRenderer>().sprite = temp;
            yield return new WaitForSeconds(.1f);

        }
        inAnimation = false;
    }




    IEnumerator Death(GameObject Dying)
    {
        inAnimation = true;
        for (int ct = 0; ct < 2; ct++)
        {
            Dying.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.3f);
            Dying.GetComponent<SpriteRenderer>().sprite = black;
            yield return new WaitForSeconds(.3f);

        }
        //kill unit
        unitList.Remove(Dying);
        Destroy(Dying);
        bool eWin = true;
        bool pWin = true;
        foreach (GameObject unit in unitList)
        {
            if (unit.GetComponent<UnitsScript>().faction == 0)
                eWin = false;
            if (unit.GetComponent<UnitsScript>().faction == 1)
                pWin = false;
        }
        if (eWin)
        {
            enemyWin = true;

        }
        if (pWin)
        {
            playerWin = true;
        }
        //if no units left of a faction, other faction wins

        inAnimation = false;
    }
    IEnumerator moveUnit(GameObject Unit, Vector3 Goal)
    {
        inAnimation = true;
        while (Unit.transform.position != Goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, Goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        inAnimation = false;
    }
    public void resetMap()
    {
        for (int i = 0; i < 20; i++)
        {
            for (int j = 0; j < 20; j++)
            {   //sets starting blue area back to green
                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = green;
                Matrix[i][j].GetComponent<TileScript>().clickable = false;
                Matrix[i][j].GetComponent<TileScript>().movesLeft = 0;

            }
        }
    }

    public void updateUI(GameObject current)
    {//display unit stats
        if (current.tag == "Unit")
        {
            if (current.GetComponent<UnitsScript>().type == 0)
                typeText.text = "Swordsman";
            if (current.GetComponent<UnitsScript>().type == 1)
                typeText.text = "Spearman";
            if (current.GetComponent<UnitsScript>().type == 2)
                typeText.text = "Archer";
            statText.text = "Health: " + current.GetComponent<UnitsScript>().currentHealth + "\nUnits: " + current.GetComponent<UnitsScript>().noOfUnits + "\nHPU: " + current.GetComponent<UnitsScript>().healthPerUnit
            + "\nFront Line: " + current.GetComponent<UnitsScript>().frontLineSize + "\nDamage: " + current.GetComponent<UnitsScript>().dieSize + "\nDice: " + current.GetComponent<UnitsScript>().noOfDice +
            "\nMove: " + current.GetComponent<UnitsScript>().moves + "\nRange: " + current.GetComponent<UnitsScript>().range;
        }
        else
        {
            typeText.text = "";
            statText.text = "";
        }

    }
    public void addArmy(GameObject army)
    {
        if (army.GetComponent<ArmyManagerController>().faction == 0)
            army1 = army;
        else if (army.GetComponent<ArmyManagerController>().faction == 1)
            army2 = army;
    }
    void FindNext(int x, int y, GameObject temporaryUnit)
    {
        if (x <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x + 1, y, 0, 0);
        if (x >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x - 1, y, 0, 1);
        if (y <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x, y + 1, 0, 2);
        if (y >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x, y - 1, 0, 3);
    }
    void FindAttack(int x, int y, GameObject temporaryUnit)
    {
        if (x <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x + 1, y, 0, 0);
        if (x >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x - 1, y, 0, 1);
        if (y <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x, y + 1, 0, 2);
        if (y >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x, y - 1, 0, 3);
    }
    void placeUnit()
    {
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
        if (hitbox)
        {//
            tempTile = GameObject.Find(hitbox.collider.gameObject.name);
            if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().isOccupied == false)
            {
                if (tempTile.GetComponent<TileScript>().clickable)
                {
                    tempTile.GetComponent<TileScript>().clickable = false;
                    tempTile.GetComponent<SpriteRenderer>().sprite = green;
                    tempTile.GetComponent<TileScript>().isOccupied = true;
                    GameObject unit = (GameObject)Instantiate(UnitPrefab, tempTile.transform.position, tempTile.transform.rotation);
                    unit.transform.position -= new Vector3(0, 0, 1);
                    unit.transform.parent = tempTile.transform;
                    unit.name = "UNIT" + countss;
                    countss++;
                    if (factionSwitched == false)
                    {
                        int faction = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].faction;
                        int type = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].type;
                        encCounter1++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                    }
                    else if (factionSwitched)
                    {
                        int faction = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].faction;
                        int type = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].type;
                        encCounter2++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                    }
                    unitList.Add(unit);

                    if (encCounter1 >= army1.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched == false)
                    //next faction's turn
                    {
                        encCounter1 = 0;
                        army1Placed = true;
                        factionSwitched = true;
                        currentFaction = 1;
                        resetMap();
                        Debug.Log("switching");
                        for (int i = 0; i < 2; i++)
                        {
                            for (int j = 0; j < 20; j++)
                            {   //sets starting blue area back to green
                                Debug.Log("CHANGING");
                                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                                Matrix[i][j].GetComponent<TileScript>().clickable = true;
                            }
                        }
                        Debug.Log("Switched");
                    }
                    else if (encCounter2 >= army2.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched)
                    {
                        encCounter2 = 0;
                        army2Placed = true;
                    }
                }
            }
        }
    }
}
