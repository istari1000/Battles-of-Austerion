﻿using UnityEngine;
using System.Collections;

public class EndTurnScript : MonoBehaviour {

    public GameObject army;
	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
	
	}
    public void OnClick()
    {
        army = GameObject.Find("ArmyManagerController");
        if (!army.GetComponent<ArmyManagerController>().attack && !army.GetComponent<ArmyManagerController>().inAnimation && !army.GetComponent<ArmyManagerController>().inRecursion && !army.GetComponent<ArmyManagerController>().placementPhase && !army.GetComponent<ArmyManagerController>().ppended && !army.GetComponent<ArmyManagerController>().isAttacking)
        {
            army.GetComponent<ArmyManagerController>().resetMap();
            foreach (GameObject unit in army.GetComponent<ArmyManagerController>().unitList)
            {
                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                unit.GetComponent<UnitsScript>().hasAttacked = false;
            }
            if (army.GetComponent<ArmyManagerController>().currentFaction == 0)
                army.GetComponent<ArmyManagerController>().currentFaction = 1;
            else
                army.GetComponent<ArmyManagerController>().currentFaction = 0;
        }
    }
}
