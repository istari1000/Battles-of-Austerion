﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class XButtonWM : MonoBehaviour {
    GameObject wm;
    void Awake()
    {
        wm = GameObject.Find("WorldMapController");
    }
    void OnMouseDown()
    {
        wm.GetComponent<WorldMapController>().LeaveRecruitment();
    }
}
