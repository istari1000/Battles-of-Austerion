﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MapScript : MonoBehaviour {
    //lists all the map tilesets
    // Use this for initialization
    private List<List<GameObject>> mapMatrix;
    private GameObject bm, wm, placement;
    public GameObject ForestTilePrefab, GrassTilePrefab, RiverTilePrefab, MountainTilePrefab, PlacementPrefab, BridgePrefab, IndoorPrefab, CityWallPrefab;
    public Sprite blue, BottomEnd, BottomLeft, BottomRight, LeftEnd, LeftToRight, RightEnd, TopEnd, TopLeft, TopRight, TopToBottom, elfIndoors, humanIndoors, callavaxIndoors, snowyForest, snowyGrass, forest, grass, cobblestone;
    private int xPos, yPos, counts, mapHeight, mapWidth;
    private bool isCity;
	void Start () {
        bm = GameObject.Find("BattleMapCreation");
        wm = GameObject.Find("WorldMapController");
        counts = 0;
        mapMatrix = new List<List<GameObject>>();
        isCity = false;
        if (!wm.GetComponent<WorldMapController>().winter)
        {
            ForestTilePrefab.GetComponent<SpriteRenderer>().sprite = forest;
            GrassTilePrefab.GetComponent<SpriteRenderer>().sprite = grass;
        }
        else {
            ForestTilePrefab.GetComponent<SpriteRenderer>().sprite = snowyForest;
            GrassTilePrefab.GetComponent<SpriteRenderer>().sprite = snowyGrass;
        }

        if (wm.GetComponent<WorldMapController>().defendingFaction == 0)
        {
            IndoorPrefab.GetComponent<SpriteRenderer>().sprite = humanIndoors;
        }
        else if (wm.GetComponent<WorldMapController>().defendingFaction == 1)
        {
            IndoorPrefab.GetComponent<SpriteRenderer>().sprite = elfIndoors;
        }
        else
        {
            IndoorPrefab.GetComponent<SpriteRenderer>().sprite = callavaxIndoors;
        }
    }
    public void createMap0()
    {
        isCity = true;
        bm.GetComponent<BattleMapCreation>().mapHeight = 15;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 15;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
            mapMatrix.Add(new List<GameObject>());
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 15 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (yPos / tileSize > 10 && yPos / tileSize < 15)
                {
                    tile = (GameObject)Instantiate(IndoorPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                    tile.GetComponent<SpriteRenderer>().sprite = callavaxIndoors;
                }
                else if ((xPos / tileSize == 0 && yPos / tileSize == 10) || (xPos / tileSize == 12 && yPos / tileSize == 7))
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = LeftEnd;
                }
                else if ((xPos / tileSize == 19 && yPos / tileSize == 10) || (xPos / tileSize == 8 && yPos / tileSize == 7))
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = RightEnd;
                }
                else if (xPos / tileSize == 7 && yPos / tileSize == 10)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = TopRight;
                }
                else if (xPos / tileSize == 13 && yPos / tileSize == 10)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = TopLeft;
                }
                else if (xPos / tileSize == 7 && yPos / tileSize == 7)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = BottomLeft;
                }
                else if (xPos / tileSize == 13 && yPos / tileSize == 7)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = BottomRight;
                }
                else if ((xPos / tileSize > 7 && xPos / tileSize < 13) && (yPos / tileSize > 7 && yPos / tileSize < 11))
                {
                    tile = (GameObject)Instantiate(IndoorPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                    tile.GetComponent<SpriteRenderer>().sprite = callavaxIndoors;
                }
                else if (yPos / tileSize > -1 && yPos / tileSize < 4)
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                else if (yPos / tileSize == 10)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = LeftToRight;
                }
                else if ((xPos / tileSize == 7 || xPos / tileSize == 13) && yPos / tileSize > 7 && yPos / tileSize < 10)
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = TopToBottom;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                    tile.GetComponent<SpriteRenderer>().sprite = cobblestone;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 0; i < mapWidth; i++)
        {
            for (int j = 15 - 2; j < 15; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //unoccupied city
    public void createMap1()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 11;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 11;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 11 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if ((xPos / tileSize == 14 && (yPos / tileSize > 3 && yPos / tileSize < 7)) || xPos / tileSize == 13)
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                    tile.GetComponent<SpriteRenderer>().sprite = cobblestone;
                }
                else if (xPos / tileSize == 14 && (yPos / tileSize == 1 || yPos / tileSize == 2 || yPos / tileSize == 8 || yPos / tileSize == 9))
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = TopToBottom;
                }
                else if (xPos / tileSize == 14 && (yPos / tileSize == 3 || yPos / tileSize == 10))
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = TopEnd;
                }
                else if (xPos / tileSize == 14 && (yPos / tileSize == 0 || yPos / tileSize == 7))
                {
                    tile = (GameObject)Instantiate(CityWallPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                    tile.GetComponent<SpriteRenderer>().sprite = BottomEnd;
                }
                else if (xPos / tileSize > 14)
                {
                    tile = (GameObject)Instantiate(IndoorPrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 11; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //checkerboard forest
    public void createMap2()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 10;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 10;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 10 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (xPos / tileSize % 2 == 0 && yPos / tileSize % 2 == 0 || xPos / tileSize % 2 == 1 && yPos / tileSize % 2 == 1)
                {
                    tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //isle of trees
    public void createMap3()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 11;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 11;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 11 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (xPos / tileSize > 8 && xPos / tileSize < 13 && yPos / tileSize > 1 && yPos / tileSize < 9)
                {
                    tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else if ((xPos / tileSize == 3 || xPos / tileSize == 4 || xPos / tileSize == 16 || xPos / tileSize == 17) && (yPos / tileSize > 3 && yPos / tileSize < 7))
                {
                    tile = (GameObject)Instantiate(BridgePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                else if ((xPos / tileSize == 3 || xPos / tileSize == 4 || xPos / tileSize == 16 || xPos / tileSize == 17) || (xPos / tileSize > 4 && xPos / tileSize < 16 && (yPos / tileSize < 2 || yPos / tileSize > 8)))
                {
                    tile = (GameObject)Instantiate(RiverTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 11; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //open plain
    public void createMap4()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 10;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 10;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 10 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                tile.GetComponent<TileScript>().cost = 1;
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }

    //path to sanctuary
    public void createMap5()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 15;
        bm.GetComponent<BattleMapCreation>().mapLength = 21;
        mapHeight = 15;
        mapWidth = 21;
        for (int i = 0; i < 21; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 21 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 15 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if ((xPos / tileSize > 5 && xPos / tileSize < 15 && yPos / tileSize > 4 && yPos / tileSize < 11) || (yPos / tileSize == 7 || yPos / tileSize == 8))
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                else
                {
                    tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 21 - 2; i < 21; i++)
        {
            for (int j = 0; j < 15; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }

    //river-forest split
    public void createMap6()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 13;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 13;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 13 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if ((xPos / tileSize > 7 && xPos / tileSize < 12) && (yPos / tileSize == 1 || yPos / tileSize == 2 || yPos / tileSize == 10 || yPos / tileSize == 11 || (yPos / tileSize > 4 && yPos / tileSize < 8)))
                {
                    tile = (GameObject)Instantiate(BridgePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                else if (xPos / tileSize > 7 && xPos / tileSize < 12)
                {
                    tile = (GameObject)Instantiate(RiverTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                }
                else if (yPos / tileSize == 3 || yPos / tileSize == 4 || yPos / tileSize == 8 | yPos / tileSize == 9)
                {
                    tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 13; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //secluded lake
    public void createMap7()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 12;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        mapHeight = 12;
        mapWidth = 20;
        for (int i = 0; i < 20; i++)
        {
            mapMatrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 12 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (xPos / tileSize > 6 && xPos / tileSize < 13 && (yPos / tileSize > 3 && yPos / tileSize < 8))
                {
                    tile = (GameObject)Instantiate(RiverTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                }
                else if (((xPos / tileSize == 5 || xPos / tileSize == 6 || xPos / tileSize == 13 || xPos / tileSize == 14) && (yPos / tileSize == 2 || yPos / tileSize == 3 || yPos / tileSize == 8 || yPos / tileSize == 9))
                    || ((xPos /tileSize > 6 && xPos/tileSize < 13) && (yPos / tileSize == 2 || yPos/tileSize == 3 || yPos / tileSize == 8 || yPos / tileSize == 9)) || ((xPos / tileSize > 4) && (xPos /tileSize < 15) && (yPos / tileSize > 1) && yPos / tileSize < 10))
                {
                    tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else
                {
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX(xPos / tileSize);
                tile.GetComponent<TileScript>().setY(yPos / tileSize);
                mapMatrix[xPos / tileSize].Add(tile);
                counts++;
            }
        }
        bm.GetComponent<BattleMapCreation>().Matrix = mapMatrix;
        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 12; j++)
            {
                placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                Vector3 z = new Vector3(0, 0, 1);
                placement.transform.position -= z;
                placement.GetComponent<SpriteRenderer>().sprite = blue;
                placement.transform.parent = mapMatrix[i][j].transform;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //switch factions
    public void switchPlacement()
    {
        if (isCity)
        {
            for (int i = 0; i < mapWidth; i++)
            {
                for (int j = 0; j < 2; j++)
                {   //sets starting blue area back to green
                    placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                    Vector3 z = new Vector3(0, 0, 1);
                    placement.transform.position -= z;
                    placement.GetComponent<SpriteRenderer>().sprite = blue;
                    placement.transform.parent = mapMatrix[i][j].transform;
                    bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
                }
            }
        }
        else
        {
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < mapHeight; j++)
                {   //sets starting blue area back to green
                    placement = (GameObject)Instantiate(PlacementPrefab, mapMatrix[i][j].transform.position, Quaternion.identity);
                    Vector3 z = new Vector3(0, 0, 1);
                    placement.transform.position -= z;
                    placement.GetComponent<SpriteRenderer>().sprite = blue;
                    placement.transform.parent = mapMatrix[i][j].transform;
                    bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
                }
            }
        }
    }
}
