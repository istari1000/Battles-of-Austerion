﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CityScript : MonoBehaviour {
    //public Sprite darkBrown, darkRed, blue, darkBlue;
    public int gold;
    public int production;
    public string cityName;
    public int faction;
    public bool isCity;
    public int xPos, yPos;
    public bool isOccupied, hasArmy, inBattle;
    public bool clickable, selected, capital;
    private GameObject fc;
	// Use this for initialization
	void Start () {
        gold = 10;
        fc = GameObject.Find("Faction Controller");
        if (isCity && faction == fc.GetComponent<FactionSelectionController>().player1Faction)
        {
            //GetComponent<SpriteRenderer>().sprite = darkBlue;
        }
        else if (isCity && faction == fc.GetComponent<FactionSelectionController>().player2Faction)
        {
            //GetComponent<SpriteRenderer>().sprite = darkRed;
        }
        else
        {
            //GetComponent<SpriteRenderer>().sprite = darkBrown;
        }
        selected = false;
        clickable = false;
        isOccupied = false;
        hasArmy = false;
	}
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
}
