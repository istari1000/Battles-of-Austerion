﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FactionSelectionController : MonoBehaviour {

    public Ray ray;
    public RaycastHit2D hitbox;
	public int player1Faction;
	public int player2Faction;
	private bool player1Picked;
	private GameObject button, sc;
    public Sprite faction1City, faction2City, unoccupiedCity;
    public Sprite Callavax, Elves, Humans;
    // Use this for initialization
    void Awake () {
		DontDestroyOnLoad(transform.gameObject);
		player1Picked = false;
	}
    void Start()
    {
        sc = GameObject.Find("StartController");
    }
	// Update is called once per frame
	void Update () {
        if ((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0))
        {
            if (sc.GetComponent<StartController>().isMobile)
                ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
            else
                ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
            if (hitbox && !player1Picked)
            {
				button = GameObject.Find(hitbox.collider.gameObject.name);
				if(button.GetComponent<SpriteRenderer>().tag == "Humans")
                {
					player1Faction = 0;
					player1Picked = true;
                    faction1City = Humans;
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Elves")
                {
			        player1Faction = 1;
					player1Picked = true;
                    faction1City = Elves;
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Callavax")
                {
                    faction1City = Callavax;
					player1Faction = 2;
					player1Picked = true;
				}
            }
							
			if (hitbox && player1Picked)
			{
				button = GameObject.Find(hitbox.collider.gameObject.name);
				if(button.GetComponent<SpriteRenderer>().tag == "Humans"){
					player2Faction = 0;
                    faction2City = Humans;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Elves"){
					player2Faction = 1;
                    faction2City = Elves;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Callavax"){
					player2Faction = 2;
                    faction2City = Callavax;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
			}
        }
    }
}
