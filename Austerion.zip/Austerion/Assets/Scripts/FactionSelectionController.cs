﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class FactionSelectionController : MonoBehaviour {

    public Ray ray;
    public RaycastHit2D hitbox;
	public int player1Faction;
	public int player2Faction;
	private bool player1Picked;
	private GameObject button;
	// Use this for initialization
	void Awake () {
		DontDestroyOnLoad(transform.gameObject);
		player1Picked = false;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetMouseButtonDown(0))
        {
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
            if (hitbox && !player1Picked)
            {
				button = GameObject.Find(hitbox.collider.gameObject.name);
				if(button.GetComponent<SpriteRenderer>().tag == "Humans"){
					player1Faction = 0;
					player1Picked = true;
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Elves"){
						player1Faction = 1;
						player1Picked = true;
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Callavax"){
					player1Faction = 2;
					player1Picked = true;
				}
            }
							
			if (hitbox && player1Picked)
			{
				button = GameObject.Find(hitbox.collider.gameObject.name);
				if(button.GetComponent<SpriteRenderer>().tag == "Humans"){
					player2Faction = 0;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Elves"){
					player2Faction = 1;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
				else if(button.GetComponent<SpriteRenderer>().tag == "Callavax"){
					player2Faction = 2;
					if (player2Faction != player1Faction)
						SceneManager.LoadScene (2);
				}
			}
        }
    }
}
