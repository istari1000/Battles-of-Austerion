﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BattleMapCreation : MonoBehaviour {
    public List<List<GameObject>> Matrix;
    public GameObject UnitPrefab, IconPrefab;
    private GameObject wm, sc, ms, tempTile, tempUnit, tempEnemy;
    private GameObject army1, army2;
    private int countss, encCounter1, encCounter2;
    private Ray ray;
    private RaycastHit2D hitbox;
    public List<GameObject> unitList;
    public Text typeText, healthText, unitText, frontText, dieText, moveText, rangeText, victoryText, restartText, damageText, placementText;
    public bool placementPhase, movementPhase, ppended, playerTurn, factionSwitched, isAttacking, attack, unitClicked;
    public bool inAnimation, inRecursion;
    public bool playerWin, enemyWin, gamePause, battleOver;
    public bool army1Placed, army2Placed;
    public Sprite blue, red, green, brown, darkgreen, black, purple, lightBlue, orange;
    private Sprite temp;
    public int currentFaction, player1Faction, player2Faction;
    public int mapHeight, mapLength, tileSize, xStart, yStart;
    private float orthoZoomSpeed;
    public Sprite healthIcon, unitsIcon, rangeIcon, moveIcon, frontIcon, d4, d6, d8;

    void Start()
    {
        //currently hard code height/width
        orthoZoomSpeed = .5f;
        tileSize = 32;
        xStart = 310;
        yStart = 144;
        victoryText.enabled = false;
        battleOver = false;
        placementText.enabled = false;
        damageText.enabled = false;
        encCounter1 = 0;
        encCounter2 = 0;
        countss = 0;
        typeText.text = "";
        healthText.text = "";
        unitText.text = "";
        frontText.text = "";
        dieText.text = "";
        moveText.text = "";
        rangeText.text = "";
        army1Placed = false;
        army2Placed = false;
        playerWin = false;
        enemyWin = false;
        gamePause = false;
        factionSwitched = false;
        placementPhase = false;
        movementPhase = false;
        unitClicked = false;
        isAttacking = false;
        attack = false;
        playerTurn = true;
        ppended = false;
        inAnimation = false;
        inRecursion = false;
        currentFaction = player1Faction;
        Matrix = new List<List<GameObject>>();
        wm = GameObject.Find("WorldMapController");
        ms = GameObject.Find("MapScript");
        player1Faction = wm.GetComponent<WorldMapController>().player1Faction;
        player2Faction = wm.GetComponent<WorldMapController>().player2Faction;
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("WorldTile");
        sc = GameObject.Find("StartController");
        foreach (GameObject tile in tiles)
        {//disable army and city sprites
            tile.GetComponent<SpriteRenderer>().enabled = false;
            ArmyManagerController[] armyy = tile.GetComponentsInChildren<ArmyManagerController>();
            foreach (ArmyManagerController army in armyy)
                army.GetComponent<SpriteRenderer>().enabled = false;
            DontDestroyOnLoad city = tile.GetComponentInChildren<DontDestroyOnLoad>();
            if (city != null)
                city.GetComponent<SpriteRenderer>().enabled = false;
        }
        if (wm.GetComponent<WorldMapController>().battleRegion == "Region0" || wm.GetComponent<WorldMapController>().battleRegion == "Region15")
            ms.GetComponent<MapScript>().createMap0();
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region3" || wm.GetComponent<WorldMapController>().battleRegion == "Region12" || wm.GetComponent<WorldMapController>().battleRegion == "Region6" || wm.GetComponent<WorldMapController>().battleRegion == "Region9")
            ms.GetComponent<MapScript>().createMap1();
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region1" || wm.GetComponent<WorldMapController>().battleRegion == "Region11")
            ms.GetComponent<MapScript>().createMap2();
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region2" || wm.GetComponent<WorldMapController>().battleRegion == "Region14")
            ms.GetComponent<MapScript>().createMap3();
        /*else if (wm.GetComponent<WorldMapController>().battleRegion == "Region5" || wm.GetComponent<WorldMapController>().battleRegion == "Region10 ")
            ms.GetComponent<MapScript>().createMap4();*/
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region4" || wm.GetComponent<WorldMapController>().battleRegion == "Region7")
            ms.GetComponent<MapScript>().createMap5();
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region5" || wm.GetComponent<WorldMapController>().battleRegion == "Region10")
            ms.GetComponent<MapScript>().createMap6();
        else if (wm.GetComponent<WorldMapController>().battleRegion == "Region8" || wm.GetComponent<WorldMapController>().battleRegion == "Region13")
            ms.GetComponent<MapScript>().createMap7();
        placementPhase = true;
    }

    void Update() {
        //zoom
        /*if (Input.touchCount == 2)
        {
            Touch touchZero = Input.GetTouch(0);
            Touch touchOne = Input.GetTouch(1);
            Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
            Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

            // Find the magnitude of the vector (the distance) between the touches in each frame.
            float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
            float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;

            // Find the difference in the distances between each frame.
            float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

            // If the camera is orthographic...
            if (GetComponent<Camera>().orthographic)
            {
                // ... change the orthographic size based on the change in distance between the touches.
                GetComponent<Camera>().orthographicSize += deltaMagnitudeDiff * orthoZoomSpeed;

                // Make sure the orthographic size never drops below zero.
                GetComponent<Camera>().orthographicSize = Mathf.Max(GetComponent<Camera>().orthographicSize, 0.1f);
            }
        }*/
        if (placementPhase)
        {
            placementText.enabled = true;
            if (!factionSwitched && encCounter1 < army1.GetComponent<ArmyManagerController>().encyclopedia.Count)//player 1
                switch (army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].type)
                {
                    case 0:
                        placementText.text = "Placing Swordsman";
                        break;
                    case 1:
                        placementText.text = "Placing Spearman";
                        break;
                    case 2:
                        placementText.text = "Placing Archer";
                        break;
                }
            else if (factionSwitched && encCounter2 < army2.GetComponent<ArmyManagerController>().encyclopedia.Count)//player 2
                switch (army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].type)
                {
                    case 0:
                        placementText.text = "Placing Swordsman";
                        break;
                    case 1:
                        placementText.text = "Placing Spearman";
                        break;
                    case 2:
                        placementText.text = "Placing Archer";
                        break;
                }
        }
        if (placementPhase && ((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)))
            placeUnit(); //placement phase
        else if (army1Placed && army2Placed && placementPhase)
        {//switch to movement
            resetMap();
            placementPhase = false;
            movementPhase = true;
            placementText.enabled = false;
            currentFaction = player1Faction;
        }
        else if (movementPhase && !battleOver)
        {
            //movement phase
            if (ppended == false && inAnimation == false && inRecursion == false)
            {
                if (((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)) && unitClicked == false && isAttacking)
                {
                    resetMap();
                    isAttacking = false;
                }
                else if (((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)) && unitClicked && tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    unitClicked = false;
                }
                else if (((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)) && !unitClicked)
                {
                    if (sc.GetComponent<StartController>().isMobile)
                        ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    else
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempUnit = GameObject.Find(hitbox.collider.gameObject.name);
                        updateUI(tempUnit);
                        if (tempUnit.tag == "Unit" && tempUnit.GetComponent<UnitsScript>().faction == currentFaction)
                        {
                            int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                            int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                            inRecursion = true;
                            if (tempUnit.GetComponent<UnitsScript>().currentMoves > 0)
                                FindNext(xValue, yValue, tempUnit);
                            else
                                FindAttack(xValue, yValue, tempUnit);
                            inRecursion = false;
							damageText.enabled = false;
                            unitClicked = true;
                            if (tempUnit.GetComponent<UnitsScript>().currentMoves == 0)
                                isAttacking = true;
                        }
                        else if (tempUnit.tag == "EndTurn")
                        {
                            resetMap();
                            foreach (GameObject unit in unitList)
                            {
                                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                                unit.GetComponent<UnitsScript>().hasAttacked = false;
                            }
                            if (currentFaction == player1Faction)
                                currentFaction = player2Faction;
							else if (currentFaction == player2Faction)
                                currentFaction = player1Faction;
                        }
                    }
                }
                else if (((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)) && unitClicked && !isAttacking && !attack)
                {
                    if (sc.GetComponent<StartController>().isMobile)
                        ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    else
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                        if (tempUnit.GetComponent<UnitsScript>().hasAttacked)
                        {
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().clickable && tempTile.GetComponent<TileScript>().isOccupied == false)
                        {
                            tempUnit.transform.parent.GetComponent<TileScript>().isOccupied = false;
                            tempUnit.transform.parent = tempTile.transform;
                            tempTile.GetComponent<TileScript>().isOccupied = true;
                            StartCoroutine(moveUnit(tempUnit, tempTile.transform.position));
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else if (tempTile.name == tempUnit.name)
                        {
                            tempTile.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else
                        {
                            unitClicked = false;
                            updateUI(tempTile);
                        }
                        resetMap();
                    }
                    else
                    {
                        resetMap();
                        unitClicked = false;
                    }
                }
                else if (isAttacking && !tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                    int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                    inRecursion = true;
                    FindAttack(xValue, yValue, tempUnit);
                    inRecursion = false;
                    isAttacking = false;
                    attack = true;

                }
                else if (((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)) && attack)
                {//attack
                    if (sc.GetComponent<StartController>().isMobile)
                        ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    else
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempEnemy = GameObject.Find(hitbox.collider.gameObject.name);
                        if (tempEnemy.tag == "Unit" && tempEnemy.GetComponent<UnitsScript>().isAttackable)
                        {
                            Attack(tempUnit, tempEnemy);
                            tempUnit.GetComponent<UnitsScript>().hasAttacked = true;
                        }
                        foreach (GameObject unit in unitList)
                            unit.GetComponent<UnitsScript>().isAttackable = false;
                        attack = false;
                        unitClicked = false;
                        updateUI(tempUnit);
                        resetMap();
                    }
                    else
                    {
                        attack = false;
                        unitClicked = false;
                        resetMap();
                    }
                }
            }
            if (movementPhase == true && ppended == true)
            {
                countss = 0;
                ppended = false;
                resetMap();
            }
        }
        //if end turn pressed, switch factions
        if (playerWin || enemyWin)
        {
            damageText.text = "";
            GameObject[] wTiles = GameObject.FindGameObjectsWithTag("WorldTile");
            foreach (GameObject tile in wTiles)
                tile.GetComponent<SpriteRenderer>().enabled = false;
            GameObject[] armies = GameObject.FindGameObjectsWithTag("Army");
            foreach (GameObject armyy in armies)
                armyy.GetComponent<SpriteRenderer>().enabled = false;
            //player wins battle
            resetMap();
            GameObject[] icons = GameObject.FindGameObjectsWithTag("Icon");
            if (icons.Length > 0)
                foreach (GameObject icon in icons)
                    Destroy(icon);
            if (playerWin)
            {
                playerWin = false;
                army1.GetComponent<ArmyManagerController>().inBattle = false;
                Destroy(army2);
                wm.GetComponent<WorldMapController>().battleWinner = army1.GetComponent<ArmyManagerController>().faction;
                army1.GetComponent<ArmyManagerController>().hasMoved = true;
                victoryText.text = army1.GetComponent<ArmyManagerController>().factionString + " Are Victorious!";
            }
            else if (enemyWin)
            {
                enemyWin = false;
                Destroy(army1);
                army2.GetComponent<ArmyManagerController>().inBattle = false;
                wm.GetComponent<WorldMapController>().battleWinner = army2.GetComponent<ArmyManagerController>().faction;
                army2.GetComponent<ArmyManagerController>().hasMoved = true;
                victoryText.text = army2.GetComponent<ArmyManagerController>().factionString + " Are Victorious!";
            }
            wm.GetComponent<WorldMapController>().inBattle = false;
            typeText.enabled = false;
            healthText.enabled = false;
            unitText.enabled = false;
            frontText.enabled = false;
            dieText.enabled = false;
            moveText.enabled = false;
            rangeText.enabled = false;
            GameObject[] units = GameObject.FindGameObjectsWithTag("Unit");
            GameObject[] tiles = GameObject.FindGameObjectsWithTag("Tile");
            foreach (GameObject unit in units)
                Destroy(unit);
            foreach (GameObject tile in tiles)
                Destroy(tile);
            Destroy(GameObject.FindGameObjectWithTag("EndTurn"));
            //change pos
            victoryText.enabled = true;
            battleOver = true;
        }
        if (battleOver && ((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)))
        {
            wm.GetComponent<WorldMapController>().returningFromBattle = true;
            SceneManager.LoadScene(2);
        }
    }

    void Attack(GameObject attacker, GameObject attackee)
    {
        int currentFrontLineHealth = attackee.GetComponent<UnitsScript>().currentFrontLineHealth;
        int currentHealth = attackee.GetComponent<UnitsScript>().currentHealth;
        int noOfUnits = attackee.GetComponent<UnitsScript>().noOfUnits;
        int diceRoll = 0;
        int frontLineSize = attackee.GetComponent<UnitsScript>().frontLineSize;
        int healthPerUnit = attackee.GetComponent<UnitsScript>().healthPerUnit;
        int attackerNoOfUnits = attacker.GetComponent<UnitsScript>().noOfUnits;
        int attackerFrontLineSize = attacker.GetComponent<UnitsScript>().frontLineSize;
        float damageDealt;
        for (int ct = 0; ct < attacker.GetComponent<UnitsScript>().noOfDice; ct++)
            diceRoll += Random.Range(1, attacker.GetComponent<UnitsScript>().dieSize);
        damageDealt = diceRoll;
        //archers max range penalty
        if (attacker.GetComponent<UnitsScript>().range > 1 && attackee.transform.parent.GetComponent<TileScript>().movesLeft <= attacker.GetComponent<UnitsScript>().range * .25)
            damageDealt *= .75f;
        //archers min range penalty
        else if (attacker.GetComponent<UnitsScript>().range > 1 && attackee.transform.parent.GetComponent<TileScript>().movesLeft >= attacker.GetComponent<UnitsScript>().range * .75)
            damageDealt *= .75f;
        //attacker lack of front line penalty
        if (attackerNoOfUnits < attackerFrontLineSize)
            damageDealt *= attackerNoOfUnits / (float)attackerFrontLineSize;
        //damage floor is 1
        if (damageDealt < 1)
            damageDealt = 1;
        //don't do more damage than front line
        if (damageDealt > currentFrontLineHealth)
            damageDealt = currentFrontLineHealth;
        damageDealt = Mathf.RoundToInt(damageDealt);
        currentHealth -= (int)damageDealt;
        noOfUnits = Mathf.CeilToInt((float)currentHealth/(float)healthPerUnit);
        currentFrontLineHealth -= (int)damageDealt;
        //if front line not full and units left to add to it
        for (int i = 0; i < frontLineSize; i++)
        {
            if (currentFrontLineHealth <= ((frontLineSize - 1) * healthPerUnit) && currentFrontLineHealth + healthPerUnit <= currentHealth)
                currentFrontLineHealth += healthPerUnit;
            else
                i = frontLineSize;
        }
        damageText.text = "Damage: " + (int)damageDealt + "!";
		damageText.enabled = true;
        if (currentHealth <= 0)
        {
            noOfUnits = 0;
            currentHealth = 0;
        }
        //reassign vars
        attackee.GetComponent<UnitsScript>().currentFrontLineHealth = currentFrontLineHealth;
        attackee.GetComponent<UnitsScript>().currentHealth = currentHealth;
        attackee.GetComponent<UnitsScript>().noOfUnits = noOfUnits;
        if (currentHealth == 0)
        {
            attackee.transform.parent.GetComponent<TileScript>().isOccupied = false;
            StartCoroutine(Death(attackee));
        }
        else
        {
            StartCoroutine(Damage(attackee));
        }
    }

    IEnumerator Damage(GameObject Damaged)
    {
        inAnimation = true;
        temp = Damaged.GetComponent<SpriteRenderer>().sprite;
        for (int ct = 0; ct < 4; ct++)
        {

            Damaged.GetComponent<SpriteRenderer>().enabled = false;
            yield return new WaitForSeconds(.1f);
            Damaged.GetComponent<SpriteRenderer>().enabled = true;
            yield return new WaitForSeconds(.1f);
        }
        inAnimation = false;
    }

    IEnumerator Death(GameObject Dying)
    {
        inAnimation = true;
        for (int ct = 0; ct < 2; ct++)
        {
            Dying.GetComponent<SpriteRenderer>().enabled = false;
            yield return new WaitForSeconds(.3f);
            Dying.GetComponent<SpriteRenderer>().enabled = true;
            yield return new WaitForSeconds(.3f);
        }
        //kill unit
        Node1 dyingNode = new Node1(Dying.GetComponent<UnitsScript>().faction, Dying.GetComponent<UnitsScript>().type);
        //remove unit from encyclopedia
        if (Dying.GetComponent<UnitsScript>().faction == army1.GetComponent<ArmyManagerController>().faction)
        {
            for (int i = 0; i < army1.GetComponent<ArmyManagerController>().encyclopedia.Count; i++)
            {
                if (army1.GetComponent<ArmyManagerController>().encyclopedia[i].type == dyingNode.type)
                {
                    army1.GetComponent<ArmyManagerController>().encyclopedia.RemoveAt(i);
                    i = army1.GetComponent<ArmyManagerController>().encyclopedia.Count;
                }
            }
        }
        else if (Dying.GetComponent<UnitsScript>().faction == army2.GetComponent<ArmyManagerController>().faction)
        {
            for (int i = 0; i < army2.GetComponent<ArmyManagerController>().encyclopedia.Count; i++)
            {
                if (army2.GetComponent<ArmyManagerController>().encyclopedia[i].type == dyingNode.type)
                {
                    army2.GetComponent<ArmyManagerController>().encyclopedia.RemoveAt(i);
                    i = army2.GetComponent<ArmyManagerController>().encyclopedia.Count;
                }
            }
        }
        unitList.Remove(Dying);
        Destroy(Dying);
        bool eWin = true;
        bool pWin = true;
        foreach (GameObject unit in unitList)
        {
            if (unit.GetComponent<UnitsScript>().faction == player1Faction)
                eWin = false;
            else if (unit.GetComponent<UnitsScript>().faction == player2Faction)
                pWin = false;
        }
        if (eWin)
            enemyWin = true;
        if (pWin)
            playerWin = true;
        //if no units left of a faction, other faction wins
        inAnimation = false;
    }

    IEnumerator moveUnit(GameObject Unit, Vector3 Goal)
    {
        inAnimation = true;
		Goal += new Vector3 (0, 0, -1);
        while (Unit.transform.position != Goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, Goal, 150 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        inAnimation = false;
    }

    public void resetMap()
    {
        for (int i = 0; i < mapLength; i++)
            for (int j = 0; j < mapHeight; j++)
            {
                Matrix[i][j].GetComponent<TileScript>().clickable = false;
                Matrix[i][j].GetComponent<TileScript>().movesLeft = 0;
                Matrix[i][j].GetComponent<TileScript>().visited = false;
            }
        GameObject[] transparents = GameObject.FindGameObjectsWithTag("Transparent");
        foreach (GameObject tile in transparents)
            Destroy(tile);
    }

    public void updateUI(GameObject current)
    {//display unit stats
        GameObject[] icons = GameObject.FindGameObjectsWithTag("Icon");
        if (icons.Length > 0)
            foreach (GameObject icon in icons)
                Destroy(icon);
        if (current.tag == "Unit")
        {
            if (current.GetComponent<UnitsScript>().type == 0)
                typeText.text = "Swordsman";
            else if (current.GetComponent<UnitsScript>().type == 1)
                typeText.text = "Spearman";
            else if (current.GetComponent<UnitsScript>().type == 2)
                typeText.text = "Archer";
            healthText.text = current.GetComponent<UnitsScript>().currentHealth.ToString();
            unitText.text = current.GetComponent<UnitsScript>().noOfUnits.ToString();
            frontText.text = current.GetComponent<UnitsScript>().frontLineSize.ToString();
            dieText.text = current.GetComponent<UnitsScript>().noOfDice.ToString();
            moveText.text = current.GetComponent<UnitsScript>().moves.ToString();
            rangeText.text = current.GetComponent<UnitsScript>().range.ToString();
            GameObject health, units, frontLine, die, movement, range;
            health = (GameObject)Instantiate(IconPrefab, new Vector3(-170, 183, -1), Quaternion.identity);
            units = (GameObject)Instantiate(IconPrefab, new Vector3(-75, 180, -1), Quaternion.identity);
            frontLine = (GameObject)Instantiate(IconPrefab, new Vector3(20, 180, -1), Quaternion.identity);
            movement = (GameObject)Instantiate(IconPrefab, new Vector3(200, 180, -1), Quaternion.identity);
            range = (GameObject)Instantiate(IconPrefab, new Vector3(295, 180, -1), Quaternion.identity);
            health.GetComponent<SpriteRenderer>().sprite = healthIcon;
            units.GetComponent<SpriteRenderer>().sprite = unitsIcon;
            frontLine.GetComponent<SpriteRenderer>().sprite = frontIcon;
            movement.GetComponent<SpriteRenderer>().sprite = moveIcon;
            range.GetComponent<SpriteRenderer>().sprite = rangeIcon;
            die = (GameObject)Instantiate(IconPrefab, new Vector3(115, 180, -1), Quaternion.identity);
            int size = current.GetComponent<UnitsScript>().dieSize;
            switch (size)
            {
                case 4:
                    die.GetComponent<SpriteRenderer>().sprite = d4;
                    break;
                case 6:
                    die.GetComponent<SpriteRenderer>().sprite = d6;
                    break;
                case 8:
                    die.GetComponent<SpriteRenderer>().sprite = d8;
                    break;
                default:
                    break;
            }
        }
        else
        {
            typeText.text = "";
            healthText.text = "";
            unitText.text = "";
            frontText.text = "";
            dieText.text = "";
            moveText.text = "";
            rangeText.text = "";
        }
    }

    public void addArmy(GameObject army)
    {
        if (army.GetComponent<ArmyManagerController>().faction == player1Faction)
            army1 = army;
        else if (army.GetComponent<ArmyManagerController>().faction == player2Faction)
            army2 = army;
    }

    void FindNext(int x, int y, GameObject Unit)
    {
        Unit.GetComponent<UnitsScript>().FindNext(x+1, y, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x-1, y, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x, y+1, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x, y-1, 0);
    }
    void FindAttack(int x, int y, GameObject Unit)
    {
        Unit.GetComponent<UnitsScript>().FindAttack(x + 1, y, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x - 1, y, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x, y + 1, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x, y - 1, 0);
    }

    void placeUnit()
    {

        if (sc.GetComponent<StartController>().isMobile)
            ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
        else
            ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
        if (hitbox)
        {//
            tempTile = GameObject.Find(hitbox.collider.gameObject.name);
            if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().isOccupied == false)
            {
                if (tempTile.GetComponent<TileScript>().clickable)
                {
                    tempTile.GetComponent<TileScript>().clickable = false;
                    foreach (Transform child in tempTile.transform)
                    {
                        Destroy(child.gameObject);
                    }
                    tempTile.GetComponent<TileScript>().isOccupied = true;
                    GameObject unit = (GameObject)Instantiate(UnitPrefab, tempTile.transform.position, tempTile.transform.rotation);
                    unit.transform.position -= new Vector3(0, 0, 1);
                    unit.transform.parent = tempTile.transform;
                    unit.name = "UNIT" + countss;
                    countss++;
                    if (factionSwitched == false)
                    {
                        int faction = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].faction;
                        int type = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].type;
                        encCounter1++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                        Vector3 scale = unit.transform.localScale;
                        scale.x *= -1;
                        unit.transform.localScale = scale;
                    }
                    else if (factionSwitched)
                    {
                        int faction = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].faction;
                        int type = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].type;
                        encCounter2++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                    }
                    unitList.Add(unit);
                    if (encCounter1 >= army1.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched == false)
                    //next faction's turn
                    {
                        encCounter1 = 0;
                        army1Placed = true;
                        factionSwitched = true;
                        currentFaction = player2Faction;
                        resetMap();
                        ms.GetComponent<MapScript>().switchPlacement();
                    }
                    else if (encCounter2 >= army2.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched)
                    {
                        encCounter2 = 0;
                        army2Placed = true;
                    }
                }
            }
        }
    }
}
