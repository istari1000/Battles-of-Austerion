﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MapScript : MonoBehaviour {
    //lists all the map tilesets
    // Use this for initialization
    private int[][] mapMatrix;
    private GameObject bm;
    private int xPos, yPos, counts;
	void Start () {
        bm = GameObject.Find("BattleMapCreation");
        counts = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
    //capital
    public void createMap0()
    {

    }
    //unoccupied city
    public void createMap1()
    {

    }
    //checkerboard forest
    public void createMap2()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 10;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        for (int i = 0; i < 20; i++)
        {
            bm.GetComponent<BattleMapCreation>().Matrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 10 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (((int)(xPos / tileSize) % 2 == 0 && (int)(yPos / tileSize) % 2 == 0) || (((int)(xPos / tileSize) % 2 == 1 && (int)(yPos / tileSize) % 2 == 1)))
                {
                    tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else
                {
                    tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX((int)xPos / tileSize);
                tile.GetComponent<TileScript>().setY((int)yPos / tileSize);
                bm.GetComponent<BattleMapCreation>().Matrix[(int)(xPos / tileSize)].Add(tile);
                counts++;
            }
        }

        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = bm.GetComponent<BattleMapCreation>().blue;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
    //isle of trees
    public void createMap3()
    {

    }
    //open plain
    public void createMap4()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 10;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        for (int i = 0; i < 20; i++)
        {
            bm.GetComponent<BattleMapCreation>().Matrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 10 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                tile.GetComponent<TileScript>().cost = 1;
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX((int)xPos / tileSize);
                tile.GetComponent<TileScript>().setY((int)yPos / tileSize);
                bm.GetComponent<BattleMapCreation>().Matrix[(int)(xPos / tileSize)].Add(tile);
                counts++;
            }
        }

        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = bm.GetComponent<BattleMapCreation>().blue;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }

    //path to sanctuary
    public void createMap5()
    {

    }

    //river-forest split
    public void createMap6()
    {

    }
    //secluded lake
    public void createMap7()
    {
        bm.GetComponent<BattleMapCreation>().mapHeight = 12;
        bm.GetComponent<BattleMapCreation>().mapLength = 20;
        for (int i = 0; i < 20; i++)
        {
            bm.GetComponent<BattleMapCreation>().Matrix.Add(new List<GameObject>());
        }
        int tileSize = bm.GetComponent<BattleMapCreation>().tileSize;
        for (xPos = 0; xPos < 20 * tileSize; xPos += tileSize)
        {
            for (yPos = 0; yPos < 12 * tileSize; yPos += tileSize)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if ((int)(xPos / tileSize) > 6 && (int)(xPos / tileSize) < 13 && ((int)(yPos / tileSize) > 3 && (int)(yPos / tileSize) < 8))
                {
                    tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().RiverTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 0;
                }
                else if (((int)(xPos / tileSize) == 5 || (int)(xPos / tileSize) == 6 || (int)(xPos / tileSize) == 13 || (int)(xPos / tileSize) == 14) &&((int)(yPos / tileSize) == 2 || (int)(yPos / tileSize) == 3 || (int)(yPos / tileSize) == 8 || (int)(yPos / tileSize) == 9))
                {
                    tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().ForestTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 2;
                }
                else
                {
                    tile = (GameObject)Instantiate(bm.GetComponent<BattleMapCreation>().GrassTilePrefab, new Vector2(xPos - bm.GetComponent<BattleMapCreation>().xStart, yPos - bm.GetComponent<BattleMapCreation>().yStart), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                }
                tile.name = "tile" + counts;
                tile.GetComponent<TileScript>().setX((int)xPos / tileSize);
                tile.GetComponent<TileScript>().setY((int)yPos / tileSize);
                bm.GetComponent<BattleMapCreation>().Matrix[(int)(xPos / tileSize)].Add(tile);
                counts++;
            }
        }

        for (int i = 20 - 2; i < 20; i++)
        {
            for (int j = 0; j < 12; j++)
            {
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<SpriteRenderer>().sprite = bm.GetComponent<BattleMapCreation>().blue;
                bm.GetComponent<BattleMapCreation>().Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
    }
}
