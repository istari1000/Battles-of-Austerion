﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//this will contain all armies, their units, and the units' stats
public class ArmyManagerController : MonoBehaviour
{
    public List<List<GameObject>> unitsSide1;
    public List<List<GameObject>> unitsSide2;
    public List<List<GameObject>> unitsSide3;
    public List<Node1> encyclopedia;
    private Dictionary<int, int> unitlist;//dictionary of units with #units and health
    public GameObject UnitPrefab;
    public Ray ray;
    public int faction;
    public RaycastHit2D hitbox;
    public Vector3 mousePosition, cameraPosition;
    public Vector2 rayVector;
    public Sprite blue, red, green, black, darkgreen;
    public Sprite redArmy, greenArmy, brownArmy;
    private Sprite temp;
    public bool hasMoved;//has this army mnoved in the world map
    public int encCounter;
    public bool inBattle;
    private GameObject battleMap;
    public int countss;//count through units to create unique names
    private GameObject tempTile;
    private GameObject tempUnit;
    private GameObject tempEnemy;
    private GameObject wm;
    private bool foundWM;
    public int tempUnitCount;

    // Use this for initialization
    void Start()
    {
        foundWM = false;
        inBattle = false;
        hasMoved = false;
        countss = 0;
        Debug.Log("created");
        encCounter = 0;
    }
    void Awake()
    {

        encyclopedia = new List<Node1>();
        DontDestroyOnLoad(transform.gameObject);
    }
    // Update is called once per frame
    void Update()
    {//placement phase
        if (SceneManager.GetActiveScene().buildIndex == 2)
            wm = GameObject.Find("WorldMapController");
        if (SceneManager.GetActiveScene().buildIndex == 3)
        {
            if (inBattle == false)
            {
                if (tag == "DEFENDER" || tag == "ATTACKER")
                {
                    tag = "Army";
                    battleMap = GameObject.Find("BattleMapCreation");
                    inBattle = true;
                    battleMap.GetComponent<BattleMapCreation>().addArmy(this.gameObject);
                }
            }
        }
    }
    public void addUnit(Node1 unit)
    {
        encyclopedia.Add(unit);
    }
    
}