﻿using UnityEngine;
using System.Collections;

public class EndTurnWM : MonoBehaviour {
    GameObject wm;
	// Use this for initialization

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
}
