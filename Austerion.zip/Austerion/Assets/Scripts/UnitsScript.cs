﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class UnitsScript : MonoBehaviour {
    public int moves;
    public int currentMoves;
    public int counter;
	public int faction;
	public int type;
	public int range;
    public int mapHeight, mapLength;
	public float timeCheck;
    public Sprite blue, red, green, darkgreen, brown;
    public Sprite CS, CA, CSS, HS, HA, HSS, ES, EA, ESS;
    //public AnimationClip
    private GameObject bm;
    public GameObject transparentTile;
    private Ray ray;
    private RaycastHit2D hitbox;
	public List<Node2> beenTo;
	public Node2 adNoded;
	public int ct;
	public bool isAttackable;
	public Text healthText; 
	public Slider healthSlider;
	public Text statText;
	//Unit stats
	public int totalHealth, currentHealth, noOfUnits, healthPerUnit, frontLineSize, currentFrontLineHealth;
	public int noOfDice, dieSize;
    public int cost;
	public bool hasAttacked;
    private GameObject transparent;
    public Animator anim;

    // Use this for initialization

    void Start () {
        counter = 0;
		isAttackable = false;
		hasAttacked = false;
        bm = GameObject.Find("BattleMapCreation");
        mapHeight = bm.GetComponent<BattleMapCreation>().mapHeight;
        mapLength = bm.GetComponent<BattleMapCreation>().mapLength;
        //human
        if (type == 0 && faction == 0) {							//Swordsman
			totalHealth = 30;
			currentHealth = 30;
			noOfUnits = 15;
			healthPerUnit = 2;
			frontLineSize = 10;
			noOfDice = 2;
			dieSize = 4;
			range = 1;
			moves = 4;
            cost = 4;
            GetComponent<SpriteRenderer>().sprite = HS;
		} else if (type == 1 && faction == 0) {						//Spearman
			totalHealth = 30;
			currentHealth = 30;
			noOfUnits = 15;
			healthPerUnit = 2;
			frontLineSize = 5;
			noOfDice = 1;
			dieSize = 4;
			range = 1;
			moves = 3;
            cost = 4;
            GetComponent<SpriteRenderer>().sprite = HSS;
        }
        else if (type == 2 && faction == 0) {						//Archer
			totalHealth = 10;
			currentHealth = 10;
			noOfUnits = 10;
			healthPerUnit = 1;
			frontLineSize = 10;
			noOfDice = 1;
			dieSize = 6;
			range = 8;
			moves = 5;
            cost = 4;
            GetComponent<SpriteRenderer>().sprite = HA;
        }

        //elves
        if (type == 0 && faction == 1)
        {                           //Swordsman
            totalHealth = 20;
            currentHealth = 20;
            noOfUnits = 10;
            healthPerUnit = 2;
            frontLineSize = 5;
            noOfDice = 2;
            dieSize = 6;
            range = 1;
            moves = 5;
            cost = 5;
            GetComponent<SpriteRenderer>().sprite = ES;
        }
        else if (type == 1 && faction == 1)
        {                       //Spearman
            totalHealth = 30;
            currentHealth = 30;
            noOfUnits = 10;
            healthPerUnit = 3;
            frontLineSize = 5;
            noOfDice = 1;
            dieSize = 4;
            range = 1;
            moves = 4;
            cost = 4;
            GetComponent<SpriteRenderer>().sprite = ESS;
        }
        else if (type == 2 && faction == 1)
        {                       //Archer
            totalHealth = 10;
            currentHealth = 10;
            noOfUnits = 10;
            healthPerUnit = 1;
            frontLineSize = 10;
            noOfDice = 1;
            dieSize = 8;
            range = 9;
            moves = 5;
            cost = 5;
            GetComponent<SpriteRenderer>().sprite = EA;
        }

        //callavanians
        if (type == 0 && faction == 2)
        {                           //Swordsman
            totalHealth = 15;
            currentHealth = 15;
            noOfUnits = 15;
            healthPerUnit = 1;
            frontLineSize = 10;
            noOfDice = 2;
            dieSize = 6;
            range = 1;
            moves = 4;
            cost = 5;
            GetComponent<SpriteRenderer>().sprite = CS;
        }
        else if (type == 1 && faction == 2)
        {                       //Spearman
            totalHealth = 40;
            currentHealth = 40;
            noOfUnits = 20;
            healthPerUnit = 2;
            frontLineSize = 10;
            noOfDice = 1;
            dieSize = 4;
            range = 1;
            moves = 3;
            cost = 3;
            GetComponent<SpriteRenderer>().sprite = CSS;
        }
        else if (type == 2 && faction == 2)
        {                       //Archer
            totalHealth = 20;
            currentHealth = 20;
            noOfUnits = 20;
            healthPerUnit = 1;
            frontLineSize = 10;
            noOfDice = 1;
            dieSize = 4;
            range = 7;
            moves = 4;
            cost = 4;
            GetComponent<SpriteRenderer>().sprite = CA;
        }

        currentFrontLineHealth = frontLineSize * healthPerUnit;
        currentMoves = moves;

	}
	
    public void FindNext(int x, int y, int county)
    {
	//directions are dont go: 0 - left; 1 - right; 2 - up; 3 - down	
		if (x >= mapLength || x < 0 || y >= mapHeight || y < 0) {
			return;
		}
        county += bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().cost;

        if (county > currentMoves) {
			return;
		}
        if (bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().cost == 0)
            return;

        if (bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().movesLeft <= (moves - county))
			bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().movesLeft = (moves - county);
		else
			return;
        if (!bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().visited)
        {
            bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().visited = true;
            transparent = (GameObject)Instantiate(transparentTile, bm.GetComponent<BattleMapCreation>().Matrix[x][y].transform.position, Quaternion.identity);
            transparent.GetComponent<SpriteRenderer>().sprite = blue;
            SpriteRenderer transparency = transparent.transform.GetComponent<SpriteRenderer>();
            Color col = transparency.color;
            col.a = 0.7f;
            transparency.color = col;
        }

        bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().clickable = true;


        FindNext(x + 1, y, county);

        FindNext(x - 1, y, county);

        FindNext(x, y - 1, county);

        FindNext(x, y + 1, county);
    }

	//Finds available attacking squares
	public void FindAttack(int x, int y, int rangeCounter)
	{
        //directions are dont go: 0 - left; 1 - right; 2 - up; 3 - down	
        if (x >= mapLength || x < 0 || y >= mapHeight || y < 0) {
			return;
		}

        //if archer, decrease attack in forests
      
        rangeCounter++;

        if (range < rangeCounter)
        {
			return;
		}
        if (bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().movesLeft <= (range - rangeCounter))
            bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().movesLeft = (range - rangeCounter);
        else
            return;

        if (!bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().visited)
        {
            bm.GetComponent<BattleMapCreation>().Matrix[x][y].GetComponent<TileScript>().visited = true;
            transparent = (GameObject)Instantiate(transparentTile, bm.GetComponent<BattleMapCreation>().Matrix[x][y].transform.position, Quaternion.identity);
            transparent.GetComponent<SpriteRenderer>().sprite = red;
            SpriteRenderer transparency = transparent.transform.GetComponent<SpriteRenderer>();
            Color col = transparency.color;
            col.a = 0.7f;
            transparency.color = col;
        }
        if (bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().transform.childCount != 0 && faction != bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().GetComponentInChildren<UnitsScript> ().faction)
        {
			bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().clickable = true;
		    bm.GetComponent<BattleMapCreation> ().Matrix [x] [y].GetComponent<TileScript> ().GetComponentInChildren<UnitsScript> ().isAttackable = true;
		}

        FindAttack(x + 1, y, rangeCounter);
        FindAttack(x - 1, y, rangeCounter);
        FindAttack(x, y - 1, rangeCounter);
        FindAttack(x, y + 1, rangeCounter);
    }
}

public class Node2
{
    public int x;
    public int y;

    public void Clear()
    {
    }

    public Node2()
    {
        x = -1;
        y = -1;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }
}