﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class DisplayVictoryScript : MonoBehaviour {

	public Text victoryText;
	public RaycastHit2D hitbox;
	public Ray ray;
	public GameObject temp;
    // Use this for initialization
    void Start()
    {
        GameObject fc = GameObject.Find("Faction Controller");
        GameObject controller = GameObject.Find("WorldMapController");
        GameObject[] armies = GameObject.FindGameObjectsWithTag("Army");
        GameObject[] map = GameObject.FindGameObjectsWithTag("WorldTile");
        if (controller.GetComponent<WorldMapController>().yourewinner == 0)
            victoryText.text = "Congratulations Humans!!";
        else if (controller.GetComponent<WorldMapController>().yourewinner == 1)
            victoryText.text = "Congratulations Elves!!";
        else if (controller.GetComponent<WorldMapController>().yourewinner == 2)
            victoryText.text = "Congratulations Callavax!!";
        //kill everything!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        Destroy(controller);
        Destroy(fc);
        foreach (GameObject army in armies)
            Destroy(army);
        foreach (GameObject tile in map)
            Destroy(tile);
    }
    void Update()
    {
        if (Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began)
            SceneManager.LoadScene(0);
    }
}