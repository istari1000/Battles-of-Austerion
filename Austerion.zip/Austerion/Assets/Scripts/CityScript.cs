﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CityScript : MonoBehaviour {
    //public Sprite darkBrown, darkRed, blue, darkBlue;
    public int gold, production, faction, xPos, yPos;
    public string cityName;
    public bool isOccupied, hasArmy, inBattle, isCity, clickable, selected, capital;

	void Start () {
        gold = 10;
        selected = false;
        clickable = false;
        isOccupied = false;
        hasArmy = false;
	}

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
}
