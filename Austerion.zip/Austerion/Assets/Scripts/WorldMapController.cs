﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class WorldMapController : MonoBehaviour
{
    public GameObject mapTile, army;
    GameObject sword, spear, archer, Gold;
    GameObject tempTile, XB, goalTile, tempArmy, endTurnWM;
    Ray ray;
    RaycastHit2D hitbox;
    int count;
    public int currentFaction;
	private GameObject fc;
    public bool inRecruitment, somethingSelected, justRecruited, showMove, allowMove;
    public bool inAnimation, inBattle, returningFromBattle;
    public GameObject RecruitButton, X, EndTurn, GoldPrefab, TransparentPrefab, CityPrefab;
    public List<GameObject> armies;//list of armies
    public List<List<GameObject>> cityList;//list of region tiles
	public int player1Faction;
	public int player2Faction;
    public bool player1Win, player2Win;
    public int battleWinner;
	public string battleCity;
    public static WorldMapController thisInstance;
    public int yourewinner;
    public bool victory;
    public int counter;
    public Text goldText, armyText;
    private GameObject transparent;
    private SpriteRenderer transparency;
    private int mapHeight, mapWidth;
    private float tileWidth, tileHeight;
    public Sprite blue;
    private float orthoZoomSpeed;
    private GameObject sc;
    Color col;
    void Awake()
    {
        if (thisInstance)
            DestroyImmediate(gameObject);
        else
        {
            DontDestroyOnLoad(transform.gameObject);
            thisInstance = this;
        }
    }
    void Start()
    {//create regions
        orthoZoomSpeed = .5f;
        yourewinner = -1;
        tileWidth = 21.45f;
        tileHeight = 14.2f;
        goldText.enabled = false;
        armyText.text = "";
        counter = 0;
        player1Win = false;
        player2Win = false;
        returningFromBattle = false;
        inAnimation = false;
        justRecruited = false;
        inRecruitment = false;
        somethingSelected = false;
        showMove = false;
        allowMove = false;
        cityList = new List<List<GameObject>>();
        sc = GameObject.Find("StartController");
        fc = GameObject.Find("Faction Controller");
        player1Faction = fc.GetComponent<FactionSelectionController>().player1Faction;
        player2Faction = fc.GetComponent<FactionSelectionController>().player2Faction;
        count = 0;
        mapWidth = 4;
        mapHeight = 4;
        for (int i = 0; i < mapWidth; i++)
        {
            cityList.Add(new List<GameObject>());
            for (int j = 0; j < mapHeight; j++)
            {
                GameObject tile = (GameObject)Instantiate(mapTile, new Vector2(i * tileWidth-36.2f, j * tileHeight-16.4f), Quaternion.identity);
                tile.name = "Region" + count;
                count++;
                if (i == 0 && j == 0)
                {//player 0 city
                    tile.GetComponent<CityScript>().capital = true;
                    tile.GetComponent<CityScript>().faction = player1Faction;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                    GameObject city = (GameObject)Instantiate(CityPrefab, tile.transform.position, Quaternion.identity);
                    city.transform.parent = tile.transform;
                    city.GetComponent<SpriteRenderer>().sprite = fc.GetComponent<FactionSelectionController>().faction1City;
                }
                if (i == mapHeight - 1 && j == mapWidth - 1)
                {//player 1 city
                    tile.GetComponent<CityScript>().capital = true;
                    tile.GetComponent<CityScript>().faction = player2Faction;
                    tile.GetComponent<CityScript>().isCity = true;
                    tile.GetComponent<CityScript>().production = 10;
                    GameObject city = (GameObject)Instantiate(CityPrefab, tile.transform.position, Quaternion.identity);
                    city.transform.parent = tile.transform;
                    city.GetComponent<SpriteRenderer>().sprite = fc.GetComponent<FactionSelectionController>().faction2City;
                }
                tile.GetComponent<CityScript>().xPos = i;
                tile.GetComponent<CityScript>().yPos = j;
                cityList[i].Add(tile);
            }
        }
        currentFaction = player1Faction;
        endTurnWM = (GameObject)Instantiate(EndTurn, new Vector3(55, -25, -1), Quaternion.identity);
        //add end turn button
    }

    // Update is called once per frame
    void Update()
    {
        if (!victory)
        { 
            if (returningFromBattle)
            {
                GameObject[] tiles = GameObject.FindGameObjectsWithTag("WorldTile");
                foreach (GameObject tile in tiles)
                {//enable army and city sprites
                    tile.GetComponent<SpriteRenderer>().enabled = true;
                    ArmyManagerController[] armyy = tile.GetComponentsInChildren<ArmyManagerController>();
                    foreach (ArmyManagerController army in armyy)
                        army.GetComponent<SpriteRenderer>().enabled = true;
                    if (tile.GetComponent<CityScript>().isCity)
                    {
                        GameObject city = tile.transform.Find("CityPrefab(Clone)").gameObject;
                        city.GetComponent<SpriteRenderer>().enabled = true;
                        if (tile.GetComponent<CityScript>().inBattle)
                        {
                            tile.GetComponent<CityScript>().inBattle = false;
                            tile.GetComponent<CityScript>().faction = battleWinner;
                            if (battleWinner == player1Faction)
                                tile.GetComponent<SpriteRenderer>().sprite = fc.GetComponent<FactionSelectionController>().faction1City;
                            else if (battleWinner == player2Faction)
                                tile.GetComponent<SpriteRenderer>().sprite = fc.GetComponent<FactionSelectionController>().faction2City;
                        }
                    }
                }
                returningFromBattle = false;
                endTurnWM = (GameObject)Instantiate(EndTurn, new Vector3(55, -25, -1), Quaternion.identity);
            }
            //victory
            if (!inBattle)
            {
                yourewinner = checkWin();
                if (yourewinner != -1)
                {
                    victory = true;
                    SceneManager.LoadScene(4);
                }
            }
            if (inAnimation == false && inBattle == false)
            {

                //default
                if (inRecruitment == false && somethingSelected == false && showMove == false && allowMove == false && ((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began)||Input.GetMouseButtonDown(0)))
                {
                    if (sc.GetComponent<StartController>().isMobile)
                        ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    else
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                        //if you click on your faction's city, go into recruitment
                        if (tempTile.tag == "EndTurnWM")
                            endTurn();
                        else if (tempTile.GetComponent<CityScript>().isCity && currentFaction == tempTile.GetComponent<CityScript>().faction)
                        {
                            armyText.text = "";
                            goldText.enabled = true;
                            tempTile.GetComponent<CityScript>().selected = true;
                            somethingSelected = true;
                            inRecruitment = true;
                            XB = (GameObject)Instantiate(X, new Vector3(60, 27, -1), Quaternion.identity);  //leave recruitment
                            archer = (GameObject)Instantiate(RecruitButton, new Vector3(55, 0, -1), Quaternion.identity);
                            sword = (GameObject)Instantiate(RecruitButton, new Vector3(55, 10, -1), Quaternion.identity);
                            spear = (GameObject)Instantiate(RecruitButton, new Vector3(55, 20, -1), Quaternion.identity);
                            Gold = (GameObject)Instantiate(GoldPrefab, new Vector3(50, 26, -1), Quaternion.identity);
                            goldText.text = tempTile.GetComponent<CityScript>().gold.ToString();
                            archer.GetComponent<RecruitmentButton>().type = 2;
                            sword.GetComponent<RecruitmentButton>().type = 0;
                            spear.GetComponent<RecruitmentButton>().type = 1;
                            archer.transform.parent = tempTile.transform;
                            sword.transform.parent = tempTile.transform;
                            spear.transform.parent = tempTile.transform;
                            XB.transform.parent = tempTile.transform;
                            //recruit in a city
                        }//else if you select an army in your faction not on a city
                        else if (tempTile.GetComponent<CityScript>().isCity == false && tempTile.GetComponent<CityScript>().isOccupied == true && tempTile.GetComponentInChildren<ArmyManagerController>().faction == currentFaction && tempTile.GetComponentInChildren<ArmyManagerController>().hasMoved == false)
                        {
                            updateUI(tempTile);
                            somethingSelected = true;
                            showMove = true;
                            int x = tempTile.GetComponent<CityScript>().xPos;
                            int y = tempTile.GetComponent<CityScript>().yPos;
                            MapMove(x, y);
                        }
                        else if (tempTile.tag == "WorldTile")
                        {
                            updateUI(tempTile);
                        }
                    }
                }
                else if (allowMove == true && ((Input.touchCount == 1 && Input.GetTouch(0).phase == TouchPhase.Began) || Input.GetMouseButtonDown(0)))
                {
                    if (sc.GetComponent<StartController>().isMobile)
                        ray = Camera.main.ScreenPointToRay(Input.GetTouch(0).position);
                    else
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        goalTile = GameObject.Find(hitbox.collider.gameObject.name);
                        //move army
                        if (goalTile.tag != "EndTurnWM" && goalTile.GetComponent<CityScript>().clickable)
                        {
                            tempTile.GetComponent<CityScript>().isOccupied = false;
                            tempTile.GetComponent<CityScript>().hasArmy = false;
                            allowMove = false;
                            ResetMap();
                            tempArmy = tempTile.GetComponentInChildren<ArmyManagerController>().gameObject;
                            StartCoroutine(moveArmy(tempArmy, goalTile));
                            tempArmy.transform.parent = goalTile.transform;

                        }
                        else if (goalTile.tag != "EndTurnWM" && goalTile.GetComponent<CityScript>().selected)
                        {
                            goalTile.GetComponent<CityScript>().selected = false;
                            allowMove = false;
                            updateUI(goalTile);
                            somethingSelected = false;
                            ResetMap();
                        }
                        else if (goalTile.tag != "EndTurnWM" && !goalTile.GetComponent<CityScript>().clickable)
                        {
                            goalTile.GetComponent<CityScript>().selected = false;
                            allowMove = false;
                            updateUI(goalTile);
                            somethingSelected = false;
                            ResetMap();
                        }

                    }
                }
                else if (justRecruited)//just recruited and army hasn't moved yet
                {
                    int x = tempTile.GetComponent<CityScript>().xPos;
                    int y = tempTile.GetComponent<CityScript>().yPos;
                    if (tempTile.GetComponent<CityScript>().hasArmy)
                    {
                        updateUI(tempTile);
                        MapMove(x, y);
                    }
                    else
                    {
                        somethingSelected = false;
                        armyText.text = "";
                    }
                    justRecruited = false;
                }
            }
        }
    }
    IEnumerator moveArmy(GameObject Unit, GameObject Goal)
    {
        inAnimation = true;
        Vector3 pos = new Vector3(0, 0, -1);
        Vector3 goal = Goal.transform.position+pos;
        while (Unit.transform.position != goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        somethingSelected = false;
        inAnimation = false;
        //if you move into an occupied space
        if (Goal.GetComponent<CityScript>().isOccupied)
        {
            //if friendly, merge armies
            GameObject temp = Goal.GetComponentInChildren<ArmyManagerController>().gameObject;
            if (temp.GetComponent<ArmyManagerController>().faction == currentFaction)
            {
                foreach (Node1 node in temp.GetComponent<ArmyManagerController>().encyclopedia)
                    Unit.GetComponent<ArmyManagerController>().encyclopedia.Add(node);
                Destroy(temp);
                Unit.GetComponent<ArmyManagerController>().hasMoved = true;
                //merge
            }
            else
            {
                armyText.text = "";
                //fight
                temp.tag = "DEFENDER";
                Unit.tag = "ATTACKER";
                inBattle = true;
                Goal.GetComponent<CityScript>().inBattle = true;
				battleCity = Goal.name;
                ResetMap();
                SceneManager.LoadScene(3);
            }
        }
        else if (Goal.GetComponent<CityScript>().isCity && !Goal.GetComponent<CityScript>().isOccupied)
        {
            Goal.GetComponent<CityScript>().faction = Unit.GetComponent<ArmyManagerController>().faction;
        }
        Goal.GetComponent<CityScript>().isOccupied = true;
        Goal.GetComponent<CityScript>().hasArmy = true;
        Unit.GetComponent<ArmyManagerController>().hasMoved = true;
    }
    public void MapMove(int x, int y)
    {
        //directions are dont go: 0 - left; 1 - right; 2 - up; 3 - down	
        if (x + 1 < mapWidth)
        {
                if (!(cityList[x + 1][y].transform.childCount > 0 && cityList[x + 1][y].GetComponentInChildren<ArmyManagerController>() != null && cityList[x + 1][y].GetComponentInChildren<ArmyManagerController>().faction == tempTile.GetComponentInChildren<ArmyManagerController>().faction && tempTile.GetComponentInChildren<ArmyManagerController>().encyclopedia.Count + cityList[x + 1][y].GetComponentInChildren<ArmyManagerController>().encyclopedia.Count > 20))
                {
                    cityList[x + 1][y].GetComponent<CityScript>().clickable = true;
                    transparent = (GameObject)Instantiate(TransparentPrefab, cityList[x + 1][y].GetComponent<SpriteRenderer>().transform.position, Quaternion.identity);
                    transparent.GetComponent<SpriteRenderer>().sprite = blue;
                    transparency = transparent.transform.GetComponent<SpriteRenderer>();
                    col = transparency.color;
                    col.a = 0.5f;
                    transparency.color = col;
                }
        }
        if (x - 1 > -1)
        {
                if (!(cityList[x - 1][y].transform.childCount > 0 && cityList[x - 1][y].GetComponentInChildren<ArmyManagerController>()!= null && cityList[x - 1][y].GetComponentInChildren<ArmyManagerController>().faction == tempTile.GetComponentInChildren<ArmyManagerController>().faction && tempTile.GetComponentInChildren<ArmyManagerController>().encyclopedia.Count + cityList[x - 1][y].GetComponentInChildren<ArmyManagerController>().encyclopedia.Count > 20))
                {
                    cityList[x - 1][y].GetComponent<CityScript>().clickable = true;
                    transparent = (GameObject)Instantiate(TransparentPrefab, cityList[x - 1][y].GetComponent<SpriteRenderer>().transform.position, Quaternion.identity);
                    transparent.GetComponent<SpriteRenderer>().sprite = blue;
                    transparency = transparent.transform.GetComponent<SpriteRenderer>();
                    col = transparency.color;
                    col.a = 0.5f;
                    transparency.color = col;
                }
        }
        if (y + 1 < mapHeight)
        {
                if (!(cityList[x][y + 1].transform.childCount > 0 && cityList[x][y + 1].GetComponentInChildren<ArmyManagerController>()!= null && cityList[x][y + 1].GetComponentInChildren<ArmyManagerController>().faction == tempTile.GetComponentInChildren<ArmyManagerController>().faction && tempTile.GetComponentInChildren<ArmyManagerController>().encyclopedia.Count + cityList[x][y + 1].GetComponentInChildren<ArmyManagerController>().encyclopedia.Count > 20))
                {
                    cityList[x][y + 1].GetComponent<CityScript>().clickable = true;
                    transparent = (GameObject)Instantiate(TransparentPrefab, cityList[x][y + 1].GetComponent<SpriteRenderer>().transform.position, Quaternion.identity);
                    transparent.GetComponent<SpriteRenderer>().sprite = blue;
                    transparency = transparent.transform.GetComponent<SpriteRenderer>();
                    col = transparency.color;
                    col.a = 0.5f;
                    transparency.color = col;
                }
        }
        if (y - 1 > -1)
        {
                if (!(cityList[x][y - 1].transform.childCount > 0 && cityList[x][y - 1].GetComponentInChildren<ArmyManagerController>()!= null && cityList[x][y - 1].GetComponentInChildren<ArmyManagerController>().faction == tempTile.GetComponentInChildren<ArmyManagerController>().faction && tempTile.GetComponentInChildren<ArmyManagerController>().encyclopedia.Count + cityList[x][y - 1].GetComponentInChildren<ArmyManagerController>().encyclopedia.Count > 20))
                {
                    cityList[x][y - 1].GetComponent<CityScript>().clickable = true;
                    transparent = (GameObject)Instantiate(TransparentPrefab, cityList[x][y - 1].GetComponent<SpriteRenderer>().transform.position, Quaternion.identity);
                    transparent.GetComponent<SpriteRenderer>().sprite = blue;
                    transparency = transparent.transform.GetComponent<SpriteRenderer>();
                    col = transparency.color;
                    col.a = 0.5f;
                    transparency.color = col;
                }
        }
        showMove = false;
        allowMove = true;
        
    }
    public void updateUI(GameObject current)
    {//display army stats
        if (current.tag == "WorldTile" && current.transform.childCount > 0)
        {
            int numOfArchers = 0;
            int numOfSwords = 0;
            int numOfSpears = 0;
            foreach (Node1 node in current.GetComponentInChildren<ArmyManagerController>().encyclopedia)
            {
                if (node.type == 0)
                    numOfSwords += 1;
                else if (node.type == 1)
                    numOfSpears += 1;
                else if (node.type == 2)
                    numOfArchers += 1;
            }
            armyText.text = "Swordsmen: " + numOfSwords + "\nSpearmen: " + numOfSpears + "\nArchers: " + numOfArchers;
        }
        else
            armyText.text = "";

    }

    public void ResetMap()
    {
        for (int i = 0; i < mapWidth; i++)
        {
            for (int j = 0; j < mapHeight; j++)
            {
                if (i == 0 && j == 0)
                {
                    //cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkBlue;
                }
                else if (i == mapWidth && j == mapHeight)
                {
                    //cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkRed;
                }
                else
                {
                    //cityList[i][j].GetComponent<SpriteRenderer>().sprite = cityList[i][j].GetComponent<CityScript>().darkBrown;
                }
                cityList[i][j].GetComponent<CityScript>().clickable = false;
                cityList[i][j].GetComponent<CityScript>().selected = false;
            }
        }
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("Transparent");
        foreach (GameObject tile in tiles)
        {
            Destroy(tile);
        }
    }
    public void LeaveRecruitment()
    {
        goldText.enabled = false;
        inRecruitment = false;
        justRecruited = true;
        Destroy(archer);
        Destroy(sword);
        Destroy(spear);
        Destroy(XB);
        Destroy(Gold);
    }
    void endTurn()
    {
        armyText.text = "";
        if (inAnimation == false && somethingSelected == false)
        {
            for (int i = 0; i < mapWidth; i++)
            {
                for (int j = 0; j < mapHeight; j++)
                {
                    if (cityList[i][j].GetComponent<CityScript>().isCity && cityList[i][j].GetComponent<CityScript>().faction == currentFaction)
                        cityList[i][j].GetComponent<CityScript>().gold += cityList[i][j].GetComponent<CityScript>().production;
                    if (cityList[i][j].GetComponent<CityScript>().isOccupied)
                        cityList[i][j].GetComponentInChildren<ArmyManagerController>().hasMoved = false;
                }
            }
            if (currentFaction == player1Faction)
                currentFaction = player2Faction;
            else if (currentFaction == player2Faction)
                currentFaction = player1Faction;
        }
    }
    int checkWin()
    {
        int playerWin = -1;
        player1Win = true;
        player2Win = true;
        foreach (List<GameObject> list in cityList)
            foreach (GameObject city in list)
            {
                if (city.GetComponent<CityScript>().isCity)
                {
                    if (city.GetComponent<CityScript>().faction == player1Faction)
                        player2Win = false;
                    else if (city.GetComponent<CityScript>().faction == player2Faction)
                        player1Win = false;
                }
            }
        if (player1Win)
            playerWin = player1Faction;
        else if (player2Win)
            playerWin = player2Faction;
        return playerWin;
    }
}