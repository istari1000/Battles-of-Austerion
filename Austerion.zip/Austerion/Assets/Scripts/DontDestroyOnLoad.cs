﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class DontDestroyOnLoad : MonoBehaviour {

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
}
