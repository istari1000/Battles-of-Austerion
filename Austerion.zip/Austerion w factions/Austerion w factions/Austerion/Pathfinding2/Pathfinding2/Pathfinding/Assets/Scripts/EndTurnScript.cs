﻿using UnityEngine;
using System.Collections;

public class EndTurnScript : MonoBehaviour {

    private GameObject bm;
	// Use this for initialization
	void Start () {

    }
	
	// Update is called once per frame
	void Update () {
	
	}
    void Awake()
    {
        bm = GameObject.Find("BattleMapCreation");
    }
    public void OnClick()
    {
        Debug.Log("END");
        if (!bm.GetComponent<BattleMapCreation>().attack && !bm.GetComponent<BattleMapCreation>().inAnimation && !bm.GetComponent<BattleMapCreation>().inRecursion && !bm.GetComponent<BattleMapCreation>().placementPhase && !bm.GetComponent<BattleMapCreation>().ppended && !bm.GetComponent<BattleMapCreation>().isAttacking)
        {
            bm.GetComponent<BattleMapCreation>().resetMap();
            foreach (GameObject unit in bm.GetComponent<BattleMapCreation>().unitList)
            {
                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                unit.GetComponent<UnitsScript>().hasAttacked = false;
            }
            if (bm.GetComponent<BattleMapCreation>().currentFaction == bm.GetComponent<BattleMapCreation>().player1Faction)
                bm.GetComponent<BattleMapCreation>().currentFaction = bm.GetComponent<BattleMapCreation>().player2Faction;
            else if (bm.GetComponent<BattleMapCreation>().currentFaction == bm.GetComponent<BattleMapCreation>().player2Faction)
                bm.GetComponent<BattleMapCreation>().currentFaction = bm.GetComponent<BattleMapCreation>().player1Faction;
        }
    }
}
