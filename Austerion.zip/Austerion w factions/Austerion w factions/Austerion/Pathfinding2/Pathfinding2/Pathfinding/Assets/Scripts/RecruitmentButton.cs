﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
public class RecruitmentButton : MonoBehaviour {
    //sprites and script for recruitment buttons
    public Sprite archer, sword, spear;
    GameObject wm, army;
    bool sprite;
    public int type;//0 sword 1 spear 2 archer
	// Use this for initialization
	void Start ()
    {
        sprite = false;
        wm = GameObject.Find("WorldMapController");
	}
	
	// Update is called once per frame
	void Update ()
    {
        if (sprite == false)
        {
            sprite = true;
            Debug.Log(type);
            switch (type)
            {
                case 0:
                    GetComponent<SpriteRenderer>().sprite = sword;
                    break;
                case 1:
                    GetComponent<SpriteRenderer>().sprite = spear;
                    break;
                case 2:
                    GetComponent<SpriteRenderer>().sprite = archer;
                    break;
                default:
                    break;
            }
        }
	}
    void OnMouseDown()
    {//if you click, check if enough money. If so, subtract cost and add unit to army
        switch (type)
        {
            case 0:
                if (transform.parent.GetComponent<CityScript>().gold >= 4)
                {
                    Recruit(type, 4);
                }
                Debug.Log("0 clicked");
                break;
            case 1:
                if (transform.parent.GetComponent<CityScript>().gold >= 4)
                {
                    Recruit(type, 4);
                }
                Debug.Log("1 clicked");
                break;
            case 2:
                if (transform.parent.GetComponent<CityScript>().gold >= 4)
                {
                    Recruit(type, 4);
                }
                Debug.Log("2 clicked");
                break;
            default:
                break;
        }
    }
    void Recruit(int types, int money)
    {//if no army present, add army as child of city
        if (transform.parent.GetComponent<CityScript>().hasArmy == false)
        {
            transform.parent.GetComponent<CityScript>().isOccupied = true;
            transform.parent.GetComponent<CityScript>().hasArmy = true;
            Vector3 pos = new Vector3(0, 0, -1);
            army = (GameObject)Instantiate(wm.GetComponent<WorldMapController>().army, (transform.parent.position+pos), transform.parent.rotation);
            army.transform.parent = transform.parent;
            army.name = "Army" + wm.GetComponent<WorldMapController>().counter;
            wm.GetComponent<WorldMapController>().counter++;
            if (transform.parent.GetComponent<CityScript>().faction == 0)
                army.GetComponent<SpriteRenderer>().sprite = army.GetComponent<ArmyManagerController>().brownArmy;
            else if (transform.parent.GetComponent<CityScript>().faction == 1)
                army.GetComponent<SpriteRenderer>().sprite = army.GetComponent<ArmyManagerController>().greenArmy;
            else if (transform.parent.GetComponent<CityScript>().faction == 2)
                army.GetComponent<SpriteRenderer>().sprite = army.GetComponent<ArmyManagerController>().redArmy;
            army.GetComponent<ArmyManagerController>().faction = transform.parent.GetComponent<CityScript>().faction;
        }
        else if (transform.parent.GetComponent<CityScript>().hasArmy)
        {
            army = transform.parent.GetComponentInChildren<ArmyManagerController>().gameObject;
        }
        if (army.GetComponent<ArmyManagerController>().encyclopedia.Count < 11)//if army not maxed out
        {
            transform.parent.GetComponent<CityScript>().gold -= money;
            wm.GetComponent<WorldMapController>().goldText.text = transform.parent.GetComponent<CityScript>().gold.ToString();
            Node1 node = new Node1(transform.parent.GetComponent<CityScript>().faction, types);
            army.GetComponent<ArmyManagerController>().addUnit(node);
        }
    }
}
