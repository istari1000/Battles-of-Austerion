﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
//for encyclopedia, currently just moves
public class Node1{


    // Use this for initialization
    public List<Node1> encyclopedia = new List<Node1>();

	public int faction;
	public int type;	//0 = sword; 1 = spear; 2 = archer

	public Node1(int factions, int types)
    {
		faction = factions;
		type = types;
    }
}
