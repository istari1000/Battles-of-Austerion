﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//this will contain all armies, their units, and the units' stats
public class ArmyManagerController : MonoBehaviour
{
    public List<List<GameObject>> unitsSide1;
    public List<List<GameObject>> unitsSide2;
    public List<List<GameObject>> unitsSide3;
    public List<Node1> encyclopedia;
    private Dictionary<int, int> unitlist;//dictionary of units with #units and health
    public GameObject UnitPrefab;
    public Ray ray;
    public int faction;
    public RaycastHit2D hitbox;
    public Vector3 mousePosition, cameraPosition;
    public Vector2 rayVector;
    public Sprite blue, red, green, black, darkgreen;
    public Sprite redArmy, greenArmy;
    private Sprite temp;
    public bool hasMoved;//has this army mnoved in the world map
    public int encCounter;
    public bool inBattle;
    private GameObject battleMap;
    public int countss;//count through units to create unique names
    private GameObject tempTile;
    private GameObject tempUnit;
    private GameObject tempEnemy;
    private GameObject wm;
    private bool foundWM;

    // Use this for initialization
    void Start()
    {
        foundWM = false;
        inBattle = false;
        hasMoved = false;
        countss = 0;
        Debug.Log("created");
        encCounter = 0;
    }
    void Awake()
    {

        encyclopedia = new List<Node1>();
        DontDestroyOnLoad(transform.gameObject);
    }
    // Update is called once per frame
    void Update()
    {//placement phase
        if (SceneManager.GetActiveScene().buildIndex == 2)
            wm = GameObject.Find("WorldMapController");
        if (SceneManager.GetActiveScene().buildIndex == 3)
        {
            if (inBattle == false)
            {
                if (tag == "DEFENDER" || tag == "ATTACKER")
                {
                    tag = "Untagged";
                    battleMap = GameObject.Find("BattleMapCreation");
                    inBattle = true;
                    battleMap.GetComponent<BattleMapCreation>().addArmy(this.gameObject);
                }
            }
            /*else if (battleMap.GetComponent<BattleMapCreation>().currentFaction == faction && inBattle)
            {

                //movement phase
                if (battleMap.GetComponent<BattleMapCreation>().movementPhase && battleMap.GetComponent<BattleMapCreation>().ppended == false && battleMap.GetComponent<BattleMapCreation>().inAnimation == false && battleMap.GetComponent<BattleMapCreation>().inRecursion == false)
                {

                    if (Input.GetMouseButtonDown(0) && battleMap.GetComponent<BattleMapCreation>().unitClicked == false && battleMap.GetComponent<BattleMapCreation>().isAttacking)
                    {
                        battleMap.GetComponent<BattleMapCreation>().resetMap();
                        battleMap.GetComponent<BattleMapCreation>().isAttacking = false;
                    }
                    else if (Input.GetMouseButtonDown(0) && battleMap.GetComponent<BattleMapCreation>().unitClicked && tempUnit.GetComponent<UnitsScript>().hasAttacked)
                    {
                        battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                    }
                    else if (Input.GetMouseButtonDown(0) && !battleMap.GetComponent<BattleMapCreation>().unitClicked)
                    {
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                        if (hitbox)
                        {
                            tempUnit = GameObject.Find(hitbox.collider.gameObject.name);
                            Debug.Log(tempUnit.name);
                            if (tempUnit.tag == "Unit" && tempUnit.GetComponent<UnitsScript>().faction == battleMap.GetComponent<BattleMapCreation>().currentFaction)
                            {
                                int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                                int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                                battleMap.GetComponent<BattleMapCreation>().inRecursion = true;
                                FindNext(xValue, yValue, tempUnit);
                                battleMap.GetComponent<BattleMapCreation>().inRecursion = false;
                                battleMap.GetComponent<BattleMapCreation>().unitClicked = true;
                                battleMap.GetComponent<BattleMapCreation>().updateUI(tempUnit);
                            }
                            else if (tempUnit.tag == "EndTurn")
                            {
                                battleMap.GetComponent<BattleMapCreation>().resetMap();
                                foreach (GameObject unit in battleMap.GetComponent<BattleMapCreation>().unitList)
                                {
                                    unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                                    unit.GetComponent<UnitsScript>().hasAttacked = false;
                                }
                                if (battleMap.GetComponent<BattleMapCreation>().currentFaction == 0)
                                    battleMap.GetComponent<BattleMapCreation>().currentFaction = 1;
                                else
                                    battleMap.GetComponent<BattleMapCreation>().currentFaction = 0;
                            }
                        }
                    }
                    else if (Input.GetMouseButtonDown(0) && battleMap.GetComponent<BattleMapCreation>().unitClicked && !battleMap.GetComponent<BattleMapCreation>().isAttacking && !battleMap.GetComponent<BattleMapCreation>().attack)
                    {
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                        if (hitbox)
                        {
                            tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                            Debug.Log(tempTile.name);
                            if (tempUnit.GetComponent<UnitsScript>().hasAttacked)
                            {
                                battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                                battleMap.GetComponent<BattleMapCreation>().updateUI(tempUnit);
                            }
                            if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().clickable && tempTile.GetComponent<TileScript>().isOccupied == false)
                            {
                                tempUnit.transform.parent.GetComponent<TileScript>().isOccupied = false;
                                tempUnit.transform.parent = tempTile.transform;
                                tempTile.GetComponent<TileScript>().isOccupied = true;
                                StartCoroutine(moveUnit(tempUnit, tempTile.transform.position));
                                tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                                battleMap.GetComponent<BattleMapCreation>().isAttacking = true;
                            }
                            else if (tempTile.name == tempUnit.name)
                            {
                                tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                                battleMap.GetComponent<BattleMapCreation>().isAttacking = true;
                            }
                            else
                            {
                                battleMap.GetComponent<BattleMapCreation>().resetMap();
                                battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                                battleMap.GetComponent<BattleMapCreation>().updateUI(tempUnit);
                            }
                            battleMap.GetComponent<BattleMapCreation>().resetMap();
                        }
                        else
                        {
                            battleMap.GetComponent<BattleMapCreation>().resetMap();
                            battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                        }
                    }
                    else if (battleMap.GetComponent<BattleMapCreation>().isAttacking && !tempUnit.GetComponent<UnitsScript>().hasAttacked)
                    {
                        int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                        int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                        battleMap.GetComponent<BattleMapCreation>().inRecursion = true;
                        float time = 0;
                        FindAttack(xValue, yValue, tempUnit);
                        time += Time.deltaTime;
                        Debug.Log(time);
                        battleMap.GetComponent<BattleMapCreation>().inRecursion = false;
                        battleMap.GetComponent<BattleMapCreation>().isAttacking = false;
                        battleMap.GetComponent<BattleMapCreation>().attack = true;

                    }
                    else if (Input.GetMouseButtonDown(0) && battleMap.GetComponent<BattleMapCreation>().attack)
                    {
                        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                        if (hitbox)
                        {
                            tempEnemy = GameObject.Find(hitbox.collider.gameObject.name);
                            Debug.Log(tempEnemy.name);
                            if (tempEnemy.tag == "Unit" && tempEnemy.GetComponent<UnitsScript>().isAttackable)
                            {
                                Attack(tempUnit, tempEnemy);

                            }
                            tempUnit.GetComponent<UnitsScript>().hasAttacked = true;
                            foreach (GameObject unit in battleMap.GetComponent<BattleMapCreation>().unitList)
                                unit.GetComponent<UnitsScript>().isAttackable = false;
                            battleMap.GetComponent<BattleMapCreation>().attack = false;
                            battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                            battleMap.GetComponent<BattleMapCreation>().updateUI(tempUnit);
                            battleMap.GetComponent<BattleMapCreation>().resetMap();

                        }
                        else
                        {
                            battleMap.GetComponent<BattleMapCreation>().attack = false;
                            battleMap.GetComponent<BattleMapCreation>().unitClicked = false;
                            battleMap.GetComponent<BattleMapCreation>().resetMap();
                        }
                    }

                }
                if (battleMap.GetComponent<BattleMapCreation>().movementPhase == true && battleMap.GetComponent<BattleMapCreation>().ppended == true)
                {
                    countss = 0;
                    battleMap.GetComponent<BattleMapCreation>().ppended = false;
                    battleMap.GetComponent<BattleMapCreation>().resetMap();
                }
            }*/
        }
    }
/*
    IEnumerator moveUnit(GameObject Unit, Vector3 Goal)
    {
        battleMap.GetComponent<BattleMapCreation>().inAnimation = true;
        while (Unit.transform.position != Goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, Goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        battleMap.GetComponent<BattleMapCreation>().inAnimation = false;
    }

    void Attack(GameObject attacker, GameObject attackee)
    {

        int diceRoll = 0;
        float damageDealt;

        for (int ct = 0; ct < attacker.GetComponent<UnitsScript>().noOfDice; ct++)
        {
            diceRoll += Random.Range(1, attacker.GetComponent<UnitsScript>().dieSize);
        }

        damageDealt = diceRoll;

        if (attacker.GetComponent<UnitsScript>().noOfUnits < attacker.GetComponent<UnitsScript>().frontLineSize)
        {
            damageDealt = (int)(damageDealt * ((float)attacker.GetComponent<UnitsScript>().noOfUnits / (float)attacker.GetComponent<UnitsScript>().frontLineSize));
        }

        int unitDeath = (int)Mathf.Floor(damageDealt / attackee.GetComponent<UnitsScript>().healthPerUnit);

        if (unitDeath > attackee.GetComponent<UnitsScript>().frontLineSize && attackee.GetComponent<UnitsScript>().noOfUnits > attackee.GetComponent<UnitsScript>().frontLineSize)
        {
            unitDeath = attackee.GetComponent<UnitsScript>().frontLineSize;
            damageDealt = unitDeath * attackee.GetComponent<UnitsScript>().healthPerUnit;
        }

        if (damageDealt < 1)
            damageDealt = 1;
        attackee.GetComponent<UnitsScript>().currentHealth -= (int)damageDealt;
        attackee.GetComponent<UnitsScript>().noOfUnits -= unitDeath;

        if (attackee.GetComponent<UnitsScript>().currentHealth <= 0)
            attackee.GetComponent<UnitsScript>().currentHealth = 0;

        if (attackee.GetComponent<UnitsScript>().currentHealth == 0)
        {
            attackee.transform.parent.GetComponent<TileScript>().isOccupied = false;
            StartCoroutine(Death(attackee));
        }
        else
        {
            StartCoroutine(Damage(attackee));
        }

    }

    IEnumerator Damage(GameObject Damaged)
    {
        battleMap.GetComponent<BattleMapCreation>().inAnimation = true;
        temp = Damaged.GetComponent<SpriteRenderer>().sprite;
        for (int ct = 0; ct < 4; ct++)
        {

            Damaged.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.1f);
            Damaged.GetComponent<SpriteRenderer>().sprite = temp;
            yield return new WaitForSeconds(.1f);

        }
        battleMap.GetComponent<BattleMapCreation>().inAnimation = false;
    }




    IEnumerator Death(GameObject Dying)
    {
        battleMap.GetComponent<BattleMapCreation>().inAnimation = true;
        for (int ct = 0; ct < 2; ct++)
        {
            Dying.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.3f);
            Dying.GetComponent<SpriteRenderer>().sprite = black;
            yield return new WaitForSeconds(.3f);

        }
        //kill unit
        battleMap.GetComponent<BattleMapCreation>().unitList.Remove(Dying);
        Destroy(Dying);
        bool eWin = true;
        bool pWin = true;
        foreach (GameObject unit in battleMap.GetComponent<BattleMapCreation>().unitList)
        {
            if (unit.GetComponent<UnitsScript>().faction == 0)
                eWin = false;
            if (unit.GetComponent<UnitsScript>().faction == 1)
                pWin = false;
        }
        if (eWin)
            battleMap.GetComponent<BattleMapCreation>().enemyWin = true;
        if(pWin)
            battleMap.GetComponent<BattleMapCreation>().playerWin = true;
        //if no units left of a faction, other faction wins

        battleMap.GetComponent<BattleMapCreation>().inAnimation = false;
    }

    void FindNext(int x, int y, GameObject temporaryUnit)
    {
        if (x <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x+1, y, 0, 0);
        if (x >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x-1, y, 0, 1);
        if (y <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x, y+1, 0, 2);
        if (y >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindNext(x, y-1, 0, 3);
    }
    void FindAttack(int x, int y, GameObject temporaryUnit)
    {
        if (x <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x + 1, y, 0, 0);
        if (x >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x - 1, y, 0, 1);
        if (y <= 19)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x, y + 1, 0, 2);
        if (y >= 0)
            temporaryUnit.GetComponent<UnitsScript>().FindAttack(x, y - 1, 0, 3);
    }*/
    public void addUnit(Node1 unit)
    {
        encyclopedia.Add(unit);
    }
    
}