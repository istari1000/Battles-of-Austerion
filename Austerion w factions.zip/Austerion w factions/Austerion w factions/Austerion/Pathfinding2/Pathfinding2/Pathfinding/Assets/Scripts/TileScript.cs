﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class TileScript : MonoBehaviour {
    public int move;
    public bool isOccupied;
    public bool clickable;
    public bool isPassable;
	private int xMatrix;
	private int yMatrix;
	public int movesLeft;
    public int cost;

	// Use this for initialization
	void Start () {
		movesLeft = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public int getX()
	{
		int temp = xMatrix;
		return temp;
	}
	public int getY()
	{
		int temp = yMatrix;
		return temp;
	}
	public void setX(int xPosInMatrix)
	{
		xMatrix = xPosInMatrix;
	}
	public void setY(int yPosInMatrix)
	{
		yMatrix = yPosInMatrix;
	}
}
