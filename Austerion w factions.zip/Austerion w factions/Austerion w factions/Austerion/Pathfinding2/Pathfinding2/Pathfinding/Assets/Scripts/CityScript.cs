﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CityScript : MonoBehaviour {
    public Sprite darkBrown, darkRed, blue, darkBlue;
    public int gold;
    public int production;
    public string cityName;
    public int faction;
    public bool isCity;
    public int xPos, yPos;
    public bool isOccupied, hasArmy;
    public bool clickable, selected;
    GameObject wm;
    private GameObject fc;
	// Use this for initialization
	void Start () {
        gold = 10;
        wm = GameObject.Find("WorldManagerController");
        fc = GameObject.Find("Faction Controller");
        if (isCity && faction == fc.GetComponent<FactionSelectionController>().player1Faction)
        {
            GetComponent<SpriteRenderer>().sprite = darkBlue;
        }
        else if (isCity && faction == fc.GetComponent<FactionSelectionController>().player2Faction)
        {
            GetComponent<SpriteRenderer>().sprite = darkRed;
        }
        else
        {
            GetComponent<SpriteRenderer>().sprite = darkBrown;
        }
        selected = false;
        clickable = false;
        isOccupied = false;
        hasArmy = false;
	}
    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }
    // Update is called once per frame
    void Update () {

	}
    void OnMouseDown()
    {
        /*if (isCity && faction == wm.GetComponent<WorldMapController>().currentFaction)
        {
            //recruit
        }
        else if(clickable)
        {
            //move if possible
        }*/
    }
    

}
