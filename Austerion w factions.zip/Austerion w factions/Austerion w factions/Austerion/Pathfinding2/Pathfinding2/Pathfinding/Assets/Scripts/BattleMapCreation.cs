﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class BattleMapCreation : MonoBehaviour {
    public List<List<GameObject>> Matrix;
    public GameObject UnitPrefab;
    public GameObject GrassTilePrefab, ForestTilePrefab, MountainTilePrefab, RiverTilePrefab;
    private GameObject wm, tempTile, tempUnit, tempEnemy;
    private GameObject army1, army2;
    private int countss, encCounter1, encCounter2;
    Ray ray;
    RaycastHit2D hitbox;
    public List<GameObject> unitList;
    public Text typeText;
    public Text statText;
    public Text victoryText, restartText;
    public bool placementPhase, movementPhase, ppended, playerTurn, factionSwitched, isAttacking, attack, unitClicked;
    public bool inAnimation, inRecursion;
    public bool playerWin, enemyWin, gamePause;
    public bool army1Placed, army2Placed;
    public Sprite blue, red, green, brown, darkgreen, black, purple, lightBlue, orange;
    private Sprite temp;
    public int currentFaction;
	public int player1Faction;
	public int player2Faction;
    float xPos = 0;
    float yPos = 0;
    // Use this for initialization
    void Start() {
        encCounter1 = 0;
        encCounter2 = 0;
        countss = 0;
        typeText.text = "";
        statText.text = "";
        army1Placed = false;
        army2Placed = false;
        playerWin = false;
        enemyWin = false;
        gamePause = false;
        factionSwitched = false;
        placementPhase = false;
        movementPhase = false;
        unitClicked = false;
        isAttacking = false;
        attack = false;
        playerTurn = true;
        ppended = false;
        inAnimation = false;
        inRecursion = false;
        //victoryText = Text.GetTextAnchorPivot
        //restartText.enabled = false;
        currentFaction = player1Faction;
        Matrix = new List<List<GameObject>>();
        wm = GameObject.Find("WorldMapController");
        player1Faction = wm.GetComponent<WorldMapController>().player1Faction;
        player2Faction = wm.GetComponent<WorldMapController>().player2Faction;
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("WorldTile");
        foreach (GameObject tile in tiles)
        {
            ArmyManagerController[] armyy = tile.GetComponentsInChildren<ArmyManagerController>();
            foreach (ArmyManagerController army in armyy)
            {
                Debug.Log("SPRITE DISABLED");
                army.GetComponent<SpriteRenderer>().enabled = false;
            }
        }
        for (int i = 0; i < 20; i++)
        {
            Matrix.Add(new List<GameObject>());
        }
        int counts = 0;
        for (xPos = 0; xPos < 200; xPos += 10)
        {
            for (yPos = 0; yPos < 100; yPos += 10)
            {//instantiates tiles and adds them to matrix
                GameObject tile;
                if (xPos == 90 || xPos == 100)
                {//river
                    if (yPos > 20 && yPos < 70)
                    {
                        tile = (GameObject)Instantiate(RiverTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                        tile.GetComponent<TileScript>().cost = 0;
                        tile.name = "tile" + counts;
                        tile.GetComponent<TileScript>().setX((int)xPos / 10);
                        tile.GetComponent<TileScript>().setY((int)yPos / 10);
                        Matrix[(int)(xPos / 10)].Add(tile);
                    }
                    else if (yPos == 20 || yPos == 70)
                    {//forest
                        tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                        tile.GetComponent<TileScript>().cost = 2;
                        tile.name = "tile" + counts;
                        tile.GetComponent<TileScript>().setX((int)xPos / 10);
                        tile.GetComponent<TileScript>().setY((int)yPos / 10);
                        Matrix[(int)(xPos / 10)].Add(tile);
                    }
                    else
                    {//grass
                        tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                        tile.GetComponent<TileScript>().cost = 1;
                        tile.name = "tile" + counts;
                        tile.GetComponent<TileScript>().setX((int)xPos / 10);
                        tile.GetComponent<TileScript>().setY((int)yPos / 10);
                        Matrix[(int)(xPos / 10)].Add(tile);
                    }
                }
                else if (xPos == 30 || xPos == 40 || xPos == 150 || xPos == 160 || xPos == 70 || xPos == 80 || xPos == 110 || xPos == 120)
                {//forest
                    if (yPos > 10 && yPos < 80)
                    {
                        tile = (GameObject)Instantiate(ForestTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                        tile.GetComponent<TileScript>().cost = 2;
                        tile.name = "tile" + counts;
                        tile.GetComponent<TileScript>().setX((int)xPos / 10);
                        tile.GetComponent<TileScript>().setY((int)yPos / 10);
                        Matrix[(int)(xPos / 10)].Add(tile);
                    }
                    else
                    {//grass
                        tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                        tile.GetComponent<TileScript>().cost = 1;
                        tile.name = "tile" + counts;
                        tile.GetComponent<TileScript>().setX((int)xPos / 10);
                        tile.GetComponent<TileScript>().setY((int)yPos / 10);
                        Matrix[(int)(xPos / 10)].Add(tile);
                    }
                }
                else
                {//grass
                    tile = (GameObject)Instantiate(GrassTilePrefab, new Vector2(xPos - 100, yPos - 50), Quaternion.identity);
                    tile.GetComponent<TileScript>().cost = 1;
                    tile.name = "tile" + counts;
                    tile.GetComponent<TileScript>().setX((int)xPos / 10);
                    tile.GetComponent<TileScript>().setY((int)yPos / 10);
                    Matrix[(int)(xPos / 10)].Add(tile);
                }
                counts++;
            }
        }


        for (int i = 18; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {
                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                Matrix[i][j].GetComponent<TileScript>().clickable = true;
            }
        }
        placementPhase = true;
    }

    // Update is called once per frame
    void Update() {
        if (placementPhase && Input.GetMouseButtonDown(0))
        {//placement phase
            placeUnit();
        }
        else if (army1Placed && army2Placed && placementPhase)
        {//switch to movement
            resetMap();
            placementPhase = false;
            movementPhase = true;
            currentFaction = player1Faction;
        }
        else if (movementPhase)
        {

            //movement phase
            if (ppended == false && inAnimation == false && inRecursion == false)
            {

                if (Input.GetMouseButtonDown(0) && unitClicked == false && isAttacking)
                {
                    resetMap();
                    isAttacking = false;
                }
                else if (Input.GetMouseButtonDown(0) && unitClicked && tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    unitClicked = false;
                }
                else if (Input.GetMouseButtonDown(0) && !unitClicked)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempUnit = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempUnit.name);
                        if (tempUnit.tag == "Unit" && tempUnit.GetComponent<UnitsScript>().faction == currentFaction)
                        {
                            int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                            int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                            inRecursion = true;
                            FindNext(xValue, yValue, tempUnit);
                            inRecursion = false;
                            unitClicked = true;
                            updateUI(tempUnit);
                        }
                        else if (tempUnit.tag == "EndTurn")
                        {
                            resetMap();
                            foreach (GameObject unit in unitList)
                            {
                                unit.GetComponent<UnitsScript>().currentMoves = unit.GetComponent<UnitsScript>().moves;
                                unit.GetComponent<UnitsScript>().hasAttacked = false;
                            }
                            if (currentFaction == player1Faction)
                                currentFaction = player2Faction;
							else if (currentFaction == player2Faction)
                                currentFaction = player1Faction;
                        }
                    }
                }
                else if (Input.GetMouseButtonDown(0) && unitClicked && !isAttacking && !attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempTile = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempTile.name);
                        if (tempUnit.GetComponent<UnitsScript>().hasAttacked)
                        {
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().clickable && tempTile.GetComponent<TileScript>().isOccupied == false)
                        {
                            tempUnit.transform.parent.GetComponent<TileScript>().isOccupied = false;
                            tempUnit.transform.parent = tempTile.transform;
                            tempTile.GetComponent<TileScript>().isOccupied = true;
                            StartCoroutine(moveUnit(tempUnit, tempTile.transform.position));
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else if (tempTile.name == tempUnit.name)
                        {
                            tempUnit.GetComponent<UnitsScript>().currentMoves = 0;
                            isAttacking = true;
                        }
                        else
                        {
                            resetMap();
                            unitClicked = false;
                            updateUI(tempUnit);
                        }
                        resetMap();
                    }
                    else
                    {
                        resetMap();
                        unitClicked = false;
                    }
                }
                else if (isAttacking && !tempUnit.GetComponent<UnitsScript>().hasAttacked)
                {
                    int xValue = tempUnit.transform.parent.GetComponent<TileScript>().getX();
                    int yValue = tempUnit.transform.parent.GetComponent<TileScript>().getY();
                    inRecursion = true;
                    float time = 0;
                    FindAttack(xValue, yValue, tempUnit);
                    time += Time.deltaTime;
                    Debug.Log(time);
                    inRecursion = false;
                    isAttacking = false;
                    attack = true;

                }
                else if (Input.GetMouseButtonDown(0) && attack)
                {
                    ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                    hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
                    if (hitbox)
                    {
                        tempEnemy = GameObject.Find(hitbox.collider.gameObject.name);
                        Debug.Log(tempEnemy.name);
                        if (tempEnemy.tag == "Unit" && tempEnemy.GetComponent<UnitsScript>().isAttackable)
                        {
                            Attack(tempUnit, tempEnemy);

                        }
                        tempUnit.GetComponent<UnitsScript>().hasAttacked = true;
                        foreach (GameObject unit in unitList)
                            unit.GetComponent<UnitsScript>().isAttackable = false;
                        attack = false;
                        unitClicked = false;
                        updateUI(tempUnit);
                        resetMap();

                    }
                    else
                    {
                        attack = false;
                        unitClicked = false;
                        resetMap();
                    }
                }

            }
            if (movementPhase == true && ppended == true)
            {
                countss = 0;
                ppended = false;
                resetMap();
            }
        }
        //if end turn pressed, switch factions
        if (playerWin)
        {
            //player wins battle
            resetMap();
            army1.GetComponent<ArmyManagerController>().inBattle = false;
            Destroy(army2);
            wm.GetComponent<WorldMapController>().inBattle = false;
            typeText.enabled = false;
            statText.enabled = false;
            victoryText.text = "GOOD JOB BRO " + army1.GetComponent<ArmyManagerController>().faction;
            //change pos
            victoryText.transform.position = new Vector3(100, 100, 0);
            //victoryText.enabled = true;
            wm.GetComponent<WorldMapController>().returningFromBattle = true;
            wm.GetComponent<WorldMapController>().battleWinner = army1.GetComponent<ArmyManagerController>().faction;
            army1.GetComponent<ArmyManagerController>().hasMoved = true;
            SceneManager.LoadScene(2);
            
        }
        if (enemyWin)
        {
            //enemy wins
            resetMap();
            Destroy(army1);
            army2.GetComponent<ArmyManagerController>().inBattle = false;
            wm.GetComponent<WorldMapController>().inBattle = false;
            typeText.enabled = false;
            statText.enabled = false;
            victoryText.text = "GOOD JOB BRO " + army2.GetComponent<ArmyManagerController>().faction;
            //change pos
            victoryText.transform.position = new Vector3(100,100,0);
            wm.GetComponent<WorldMapController>().returningFromBattle = true;
            wm.GetComponent<WorldMapController>().battleWinner = army2.GetComponent<ArmyManagerController>().faction;
            army2.GetComponent<ArmyManagerController>().hasMoved = true;
            SceneManager.LoadScene(2);
            //victoryText.enabled = true;

        }
    }
    void Attack(GameObject attacker, GameObject attackee)
    {

        int diceRoll = 0;
        float damageDealt;

        for (int ct = 0; ct < attacker.GetComponent<UnitsScript>().noOfDice; ct++)
        {
            diceRoll += Random.Range(1, attacker.GetComponent<UnitsScript>().dieSize);
        }

        damageDealt = diceRoll;

        if (attacker.GetComponent<UnitsScript>().noOfUnits < attacker.GetComponent<UnitsScript>().frontLineSize)
        {
            damageDealt = (int)(damageDealt * ((float)attacker.GetComponent<UnitsScript>().noOfUnits / (float)attacker.GetComponent<UnitsScript>().frontLineSize));
        }

        int unitDeath = (int)Mathf.Floor(damageDealt / attackee.GetComponent<UnitsScript>().healthPerUnit);

        if (unitDeath > attackee.GetComponent<UnitsScript>().frontLineSize && attackee.GetComponent<UnitsScript>().noOfUnits > attackee.GetComponent<UnitsScript>().frontLineSize)
        {
            unitDeath = attackee.GetComponent<UnitsScript>().frontLineSize;
            damageDealt = unitDeath * attackee.GetComponent<UnitsScript>().healthPerUnit;
        }

        if (damageDealt < 1)
            damageDealt = 1;
        attackee.GetComponent<UnitsScript>().currentHealth -= (int)damageDealt;
        attackee.GetComponent<UnitsScript>().noOfUnits -= unitDeath;

        if (attackee.GetComponent<UnitsScript>().currentHealth <= 0)
            attackee.GetComponent<UnitsScript>().currentHealth = 0;

        if (attackee.GetComponent<UnitsScript>().currentHealth == 0)
        {
            attackee.transform.parent.GetComponent<TileScript>().isOccupied = false;
            StartCoroutine(Death(attackee));
        }
        else
        {
            StartCoroutine(Damage(attackee));
        }

    }

    IEnumerator Damage(GameObject Damaged)
    {
        inAnimation = true;
        temp = Damaged.GetComponent<SpriteRenderer>().sprite;
        for (int ct = 0; ct < 4; ct++)
        {

            Damaged.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.1f);
            Damaged.GetComponent<SpriteRenderer>().sprite = temp;
            yield return new WaitForSeconds(.1f);

        }
        inAnimation = false;
    }




    IEnumerator Death(GameObject Dying)
    {
        inAnimation = true;
        for (int ct = 0; ct < 2; ct++)
        {
            Dying.GetComponent<SpriteRenderer>().sprite = red;
            yield return new WaitForSeconds(.3f);
            Dying.GetComponent<SpriteRenderer>().sprite = black;
            yield return new WaitForSeconds(.3f);

        }
        //kill unit
        Node1 dyingNode = new Node1(Dying.GetComponent<UnitsScript>().faction, Dying.GetComponent<UnitsScript>().type);
        //remove unit from encyclopedia
        if (Dying.GetComponent<UnitsScript>().faction == army1.GetComponent<ArmyManagerController>().faction)
        {
            for (int i = 0; i < army1.GetComponent<ArmyManagerController>().encyclopedia.Count; i++)
            {
                if (army1.GetComponent<ArmyManagerController>().encyclopedia[i].type == dyingNode.type)
                {
                    army1.GetComponent<ArmyManagerController>().encyclopedia.RemoveAt(i);
                    i = army1.GetComponent<ArmyManagerController>().encyclopedia.Count;
                }
            }
        }
        else if (Dying.GetComponent<UnitsScript>().faction == army2.GetComponent<ArmyManagerController>().faction)
        {
            for (int i = 0; i < army2.GetComponent<ArmyManagerController>().encyclopedia.Count; i++)
            {
                if (army2.GetComponent<ArmyManagerController>().encyclopedia[i].type == dyingNode.type)
                {
                    army2.GetComponent<ArmyManagerController>().encyclopedia.RemoveAt(i);
                    i = army2.GetComponent<ArmyManagerController>().encyclopedia.Count;
                }
            }
        }
        unitList.Remove(Dying);
        Destroy(Dying);
        bool eWin = true;
        bool pWin = true;
        foreach (GameObject unit in unitList)
        {
            if (unit.GetComponent<UnitsScript>().faction == player1Faction)
                eWin = false;
            if (unit.GetComponent<UnitsScript>().faction == player2Faction)
                pWin = false;
        }
        if (eWin)
        {
            enemyWin = true;

        }
        if (pWin)
        {
            playerWin = true;
        }
        //if no units left of a faction, other faction wins

        inAnimation = false;
    }
    IEnumerator moveUnit(GameObject Unit, Vector3 Goal)
    {
        inAnimation = true;
        while (Unit.transform.position != Goal)
        {
            Unit.transform.position = Vector3.MoveTowards(Unit.transform.position, Goal, 25 * Time.deltaTime);
            yield return new WaitForEndOfFrame();
        }
        inAnimation = false;
    }
    public void resetMap()
    {
        for (int i = 0; i < 20; i++)
        {
            for (int j = 0; j < 10; j++)
            {   //sets starting blue area back to green
                if (Matrix[i][j].GetComponent<TileScript>().cost == 0)
                    Matrix[i][j].GetComponent<SpriteRenderer>().sprite = lightBlue;
                else if (Matrix[i][j].GetComponent<TileScript>().cost == 1)
                    Matrix[i][j].GetComponent<SpriteRenderer>().sprite = green;
                else if (Matrix[i][j].GetComponent<TileScript>().cost == 2)
                    Matrix[i][j].GetComponent<SpriteRenderer>().sprite = orange;
                Matrix[i][j].GetComponent<TileScript>().clickable = false;
                Matrix[i][j].GetComponent<TileScript>().movesLeft = 0;
            }
        }
        GameObject[] transparents = GameObject.FindGameObjectsWithTag("Transparent");
        foreach (GameObject tile in transparents)
            Destroy(tile);
    }

    public void updateUI(GameObject current)
    {//display unit stats
        if (current.tag == "Unit")
        {
            if (current.GetComponent<UnitsScript>().type == 0)
                typeText.text = "Swordsman";
            if (current.GetComponent<UnitsScript>().type == 1)
                typeText.text = "Spearman";
            if (current.GetComponent<UnitsScript>().type == 2)
                typeText.text = "Archer";
            statText.text = "Health: " + current.GetComponent<UnitsScript>().currentHealth + "\nUnits: " + current.GetComponent<UnitsScript>().noOfUnits + "\nHPU: " + current.GetComponent<UnitsScript>().healthPerUnit
            + "\nFront Line: " + current.GetComponent<UnitsScript>().frontLineSize + "\nDamage: " + current.GetComponent<UnitsScript>().dieSize + "\nDice: " + current.GetComponent<UnitsScript>().noOfDice +
            "\nMove: " + current.GetComponent<UnitsScript>().moves + "\nRange: " + current.GetComponent<UnitsScript>().range;
        }
        else
        {
            typeText.text = "";
            statText.text = "";
        }

    }
    public void addArmy(GameObject army)
    {
        if (army.GetComponent<ArmyManagerController>().faction == player1Faction)
            army1 = army;
        else if (army.GetComponent<ArmyManagerController>().faction == player2Faction)
            army2 = army;
    }
    void FindNext(int x, int y, GameObject Unit)
    {
        Unit.GetComponent<UnitsScript>().FindNext(x+1, y, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x-1, y, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x, y+1, 0);
        Unit.GetComponent<UnitsScript>().FindNext(x, y-1, 0);
    }
    void FindAttack(int x, int y, GameObject Unit)
    {
        Unit.GetComponent<UnitsScript>().FindAttack(x + 1, y, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x - 1, y, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x, y + 1, 0);
        Unit.GetComponent<UnitsScript>().FindAttack(x, y - 1, 0);
    }

    void placeUnit()
    {
        ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        //cameraPosition = Camera.main.ScreenToWorldPoint(mousePosition);
        hitbox = Physics2D.Raycast(ray.origin, ray.direction, Mathf.Infinity);
        if (hitbox)
        {//
            tempTile = GameObject.Find(hitbox.collider.gameObject.name);
            if (tempTile.tag == "Tile" && tempTile.GetComponent<TileScript>().isOccupied == false)
            {
                if (tempTile.GetComponent<TileScript>().clickable)
                {
                    tempTile.GetComponent<TileScript>().clickable = false;
                    tempTile.GetComponent<SpriteRenderer>().sprite = green;
                    tempTile.GetComponent<TileScript>().isOccupied = true;
                    GameObject unit = (GameObject)Instantiate(UnitPrefab, tempTile.transform.position, tempTile.transform.rotation);
                    unit.transform.position -= new Vector3(0, 0, 1);
                    unit.transform.parent = tempTile.transform;
                    unit.name = "UNIT" + countss;
                    countss++;
                    if (factionSwitched == false)
                    {
                        int faction = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].faction;
                        int type = army1.GetComponent<ArmyManagerController>().encyclopedia[encCounter1].type;
                        encCounter1++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                    }
                    else if (factionSwitched)
                    {
                        int faction = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].faction;
                        int type = army2.GetComponent<ArmyManagerController>().encyclopedia[encCounter2].type;
                        encCounter2++;//needs to be expanded
                        unit.GetComponent<UnitsScript>().faction = faction;
                        unit.GetComponent<UnitsScript>().type = type;
                    }
                    unitList.Add(unit);

                    if (encCounter1 >= army1.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched == false)
                    //next faction's turn
                    {
                        encCounter1 = 0;
                        army1Placed = true;
                        factionSwitched = true;
                        currentFaction = player2Faction;
                        resetMap();
                        Debug.Log("switching");
                        for (int i = 0; i < 2; i++)
                        {
                            for (int j = 0; j < 10; j++)
                            {   //sets starting blue area back to green
                                Debug.Log("CHANGING");
                                Matrix[i][j].GetComponent<SpriteRenderer>().sprite = blue;
                                Matrix[i][j].GetComponent<TileScript>().clickable = true;
                            }
                        }
                        Debug.Log("Switched");
                    }
                    else if (encCounter2 >= army2.GetComponent<ArmyManagerController>().encyclopedia.Count && factionSwitched)
                    {
                        encCounter2 = 0;
                        army2Placed = true;
                    }
                }
            }
        }
    }
}
