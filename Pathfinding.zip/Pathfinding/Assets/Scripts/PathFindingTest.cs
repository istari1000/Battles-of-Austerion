﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class PathFindingTest : MonoBehaviour {

	//pick starting nodes and end nodes
	public int start = 0;
	public int finish = 0;
	public int[,] map = new int[5, 5];
	public GameObject mapGroup;

	// Use this for initialization
	void Start () {
		//Creates the map, 0 = passable, 1 = impassable
		for (int mapRow = 0; mapRow < 5; mapRow++)
			for (int mapColumn = 0; mapColumn < 5; mapColumn++)
				map [mapRow, mapColumn] = 0;
		
	}		

	//Resets map. Currently Forest is tagged as impassable, 1, and grass is tagged as passable, 0.
	private int [,] resetMap(int [,] map)
	{
		int ct = 0;
		int ct1 = 0;
		int ct2 = 0;
		var graph = new Graph (map);
		foreach (var node in graph.nodes) {

			if (ct2 == 5) {
				ct2 = 0;
				ct1 = 0;
				ct++;
			}
			if (GetImage (node.label).tag.Equals("Grass")) {
				map [ct, ct1] = 0;
				GetImage (node.label).color = Color.white;
			} else if (GetImage (node.label).tag.Equals("Forest")) {
				GetImage (node.label).color = Color.black;
				map[ct,ct1] = 1;
			}
			ct1++;
			ct2++;
		}
		return map;
	}

	private Image GetImage(string label){
		var id = Int32.Parse (label);
		var go = mapGroup.transform.GetChild (id).gameObject;
		return go.GetComponent<Image> ();
	}



	IEnumerator WaitForKeyDown(KeyCode keyCode)
	{
		while (!Input.GetKeyDown(keyCode))
			yield return null;
	}
		
	// Update is called once per frame
	void Update () {

		//Pressing down key causes search to start.
		if( Input.GetKey("down"))
		{
			print ("About to reset Map");
			var graph = new Graph (resetMap (map));


			var search = new Search (graph);
			search.Start (graph.nodes [start], graph.nodes [finish]);

			while (!search.finished) {
				search.Step ();
			}

			print ("Search done. Path length " + search.path.Count + " iterations " + search.iterations);



			//Retrace path and make those nodes red

			foreach (var node in search.path) {
				GetImage (node.label).color = Color.red;
				print ("path made red");
			}
					

		}

		//Pressing up key causes map to be reset to initial values
		if (Input.GetKey ("up")) {
			print ("About to reset Map");
			var graph = new Graph (resetMap (map));
		}
	}
}
