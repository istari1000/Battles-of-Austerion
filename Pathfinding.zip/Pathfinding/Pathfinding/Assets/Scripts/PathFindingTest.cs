﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class PathFindingTest : MonoBehaviour {

	//pick starting nodes and end nodes
	public int start = 0;
	public int finish = 0;
	public GameObject mapGroup;

	// Use this for initialization
	void Start () {
		//Creates the map, 0 = passable, 1 = impassable
		//Right now row and column size are fixed.
		int[,] map = new int[5, 5];
		//Sets map up to be all 0's
		for (int mapRow = 0; mapRow < 5; mapRow++)
			for (int mapColumn = 0; mapColumn < 5; mapColumn++)
				map [mapRow, mapColumn] = 0;
		var graph1 = new Graph (map);

		//Sets map to match up to the image color of the canvas map.
		int ct = 0;
		int ct1 = 0;
		int ct2 = 0;
		foreach (var node in graph1.nodes) {
			if (ct2 == 5) {
				ct2 = 0;
				ct1 = 0;
				ct++;
			}
			if (GetImage (node.label).color == Color.white) {
				print ("White found");
				map [ct, ct1] = 0;
			} else if (GetImage (node.label).color == Color.black) {
				print ("Black found");
				map[ct,ct1] = 1;
			}
			ct1++;
			ct2++;
		}

		var graph = new Graph (map);

		var search = new Search (graph);
		search.Start (graph.nodes [start], graph.nodes [finish]);

		while (!search.finished) {
			search.Step();
		}

		print ("Search done. Path length " + search.path.Count + " iterations " + search.iterations);
	

		//Retrace path and make those nodes red
		foreach (var node in search.path) {
			GetImage (node.label).color = Color.red;
		}
	}

	private Image GetImage(string label){
		var id = Int32.Parse (label);
		var go = mapGroup.transform.GetChild (id).gameObject;
		return go.GetComponent<Image> ();
	}

	void ResetMapGroup(Graph graph){
		foreach (var node in graph.nodes) {
			GetImage (node.label).color = node.adjacent.Count == 0 ? Color.white : Color.grey;
		}

	}
		
	// Update is called once per frame
	void Update () {
	
	}
}
